-- MySQL dump 10.13  Distrib 5.1.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: wpf_multi
-- ------------------------------------------------------
-- Server version	5.1.41-3ubuntu12.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_2_commentmeta`
--

DROP TABLE IF EXISTS `wp_2_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_commentmeta`
--

LOCK TABLES `wp_2_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_2_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_2_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_comments`
--

DROP TABLE IF EXISTS `wp_2_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_approved` (`comment_approved`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `wp_2_comments_ibfk1` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_comments`
--

LOCK TABLES `wp_2_comments` WRITE;
/*!40000 ALTER TABLE `wp_2_comments` DISABLE KEYS */;
INSERT INTO `wp_2_comments` VALUES (1,1,'Mr WordPress','','http://localhost/','','2011-03-29 10:37:15','2011-03-29 10:37:15','Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.',0,'1','','',NULL,NULL);
/*!40000 ALTER TABLE `wp_2_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_links`
--

DROP TABLE IF EXISTS `wp_2_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_links`
--

LOCK TABLES `wp_2_links` WRITE;
/*!40000 ALTER TABLE `wp_2_links` DISABLE KEYS */;
INSERT INTO `wp_2_links` VALUES (1,'http://codex.wordpress.org/','Documentation','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(2,'http://wordpress.org/news/','WordPress Blog','','','','Y',1,0,'0000-00-00 00:00:00','','','http://wordpress.org/news/feed/'),(3,'http://wordpress.org/extend/ideas/','Suggest Ideas','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(4,'http://wordpress.org/support/','Support Forum','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(5,'http://wordpress.org/extend/plugins/','Plugins','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(6,'http://wordpress.org/extend/themes/','Themes','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(7,'http://planet.wordpress.org/','WordPress Planet','','','','Y',1,0,'0000-00-00 00:00:00','','','');
/*!40000 ALTER TABLE `wp_2_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_options`
--

DROP TABLE IF EXISTS `wp_2_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_options`
--

LOCK TABLES `wp_2_options` WRITE;
/*!40000 ALTER TABLE `wp_2_options` DISABLE KEYS */;
INSERT INTO `wp_2_options` VALUES (1,0,'siteurl','http://mu.ludolo.it/blog2/','yes'),(2,0,'blogname','WP Frontman Blog 2','yes'),(3,0,'blogdescription','Just another WP Frontman Sites site','yes'),(4,0,'users_can_register','0','yes'),(5,0,'admin_email','ludo@qix.it','yes'),(6,0,'start_of_week','1','yes'),(7,0,'use_balanceTags','0','yes'),(8,0,'use_smilies','1','yes'),(9,0,'require_name_email','1','yes'),(10,0,'comments_notify','1','yes'),(11,0,'posts_per_rss','10','yes'),(12,0,'rss_use_excerpt','0','yes'),(13,0,'mailserver_url','mail.example.com','yes'),(14,0,'mailserver_login','login@example.com','yes'),(15,0,'mailserver_pass','password','yes'),(16,0,'mailserver_port','110','yes'),(17,0,'default_category','1','yes'),(18,0,'default_comment_status','open','yes'),(19,0,'default_ping_status','open','yes'),(20,0,'default_pingback_flag','1','yes'),(21,0,'default_post_edit_rows','20','yes'),(22,0,'posts_per_page','10','yes'),(23,0,'date_format','F j, Y','yes'),(24,0,'time_format','g:i a','yes'),(25,0,'links_updated_date_format','F j, Y g:i a','yes'),(26,0,'links_recently_updated_prepend','<em>','yes'),(27,0,'links_recently_updated_append','</em>','yes'),(28,0,'links_recently_updated_time','120','yes'),(29,0,'comment_moderation','0','yes'),(30,0,'moderation_notify','1','yes'),(31,0,'permalink_structure','/%category%/%post_id%/%postname%/','yes'),(32,0,'gzipcompression','0','yes'),(33,0,'hack_file','0','yes'),(34,0,'blog_charset','UTF-8','yes'),(35,0,'moderation_keys','','no'),(36,0,'active_plugins','a:0:{}','yes'),(37,0,'home','http://mu.ludolo.it/blog2/','yes'),(38,0,'category_base','/categoria','yes'),(39,0,'ping_sites','http://rpc.pingomatic.com/','yes'),(40,0,'advanced_edit','0','yes'),(41,0,'comment_max_links','2','yes'),(42,0,'gmt_offset','0','yes'),(43,0,'default_email_category','1','yes'),(44,0,'recently_edited','','no'),(45,0,'template','twentyten','yes'),(46,0,'stylesheet','twentyten','yes'),(47,0,'comment_whitelist','1','yes'),(48,0,'blacklist_keys','','no'),(49,0,'comment_registration','0','yes'),(50,0,'rss_language','en','yes'),(51,0,'html_type','text/html','yes'),(52,0,'use_trackback','0','yes'),(53,0,'default_role','subscriber','yes'),(54,0,'db_version','19470','yes'),(55,0,'uploads_use_yearmonth_folders','1','yes'),(56,0,'upload_path','wp-content/blogs.dir/2/files','yes'),(57,0,'blog_public','1','yes'),(58,0,'default_link_category','2','yes'),(59,0,'show_on_front','posts','yes'),(60,0,'tag_base','/tag','yes'),(61,0,'show_avatars','1','yes'),(62,0,'avatar_rating','G','yes'),(63,0,'upload_url_path','','yes'),(64,0,'thumbnail_size_w','150','yes'),(65,0,'thumbnail_size_h','150','yes'),(66,0,'thumbnail_crop','1','yes'),(67,0,'medium_size_w','300','yes'),(68,0,'medium_size_h','300','yes'),(69,0,'avatar_default','mystery','yes'),(70,0,'enable_app','0','yes'),(71,0,'enable_xmlrpc','0','yes'),(72,0,'large_size_w','1024','yes'),(73,0,'large_size_h','1024','yes'),(74,0,'image_default_link_type','file','yes'),(75,0,'image_default_size','','yes'),(76,0,'image_default_align','','yes'),(77,0,'close_comments_for_old_posts','0','yes'),(78,0,'close_comments_days_old','14','yes'),(79,0,'thread_comments','1','yes'),(80,0,'thread_comments_depth','5','yes'),(81,0,'page_comments','0','yes'),(82,0,'comments_per_page','50','yes'),(83,0,'default_comments_page','newest','yes'),(84,0,'comment_order','asc','yes'),(85,0,'sticky_posts','a:0:{}','yes'),(86,0,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(87,0,'widget_text','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(88,0,'widget_rss','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(89,0,'timezone_string','','yes'),(90,0,'embed_autourls','1','yes'),(91,0,'embed_size_w','','yes'),(92,0,'embed_size_h','600','yes'),(93,0,'page_for_posts','0','yes'),(94,0,'page_on_front','0','yes'),(95,0,'default_post_format','0','yes'),(96,0,'wp_2_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes'),(97,0,'fileupload_url','http://mu.ludolo.it/blog2/files','yes'),(98,0,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(99,0,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(100,0,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(101,0,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(102,0,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(103,0,'sidebars_widgets','a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:19:\"primary-widget-area\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:21:\"secondary-widget-area\";a:0:{}s:24:\"first-footer-widget-area\";a:0:{}s:25:\"second-footer-widget-area\";a:0:{}s:24:\"third-footer-widget-area\";a:0:{}s:25:\"fourth-footer-widget-area\";a:0:{}s:13:\"array_version\";i:3;}','yes'),(105,0,'WPLANG','','yes'),(106,0,'db_upgraded','','yes'),(107,0,'allowedthemes','a:0:{}','yes'),(109,0,'blog_upload_space','','yes'),(111,0,'widget_pages','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(112,0,'widget_calendar','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(113,0,'widget_links','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(114,0,'widget_tag_cloud','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(115,0,'widget_nav_menu','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(117,0,'cron','a:3:{i:1326284326;a:1:{s:21:\"update_network_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1326295625;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}','yes'),(118,0,'dashboard_widget_options','a:4:{s:25:\"dashboard_recent_comments\";a:1:{s:5:\"items\";i:5;}s:24:\"dashboard_incoming_links\";a:5:{s:4:\"home\";s:25:\"http://mu.ludolo.it/blog2\";s:4:\"link\";s:101:\"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://mu.ludolo.it/blog2/\";s:3:\"url\";s:134:\"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://mu.ludolo.it/blog2/\";s:5:\"items\";i:10;s:9:\"show_date\";b:0;}s:17:\"dashboard_primary\";a:7:{s:4:\"link\";s:26:\"http://wordpress.org/news/\";s:3:\"url\";s:31:\"http://wordpress.org/news/feed/\";s:5:\"title\";s:14:\"WordPress Blog\";s:5:\"items\";i:2;s:12:\"show_summary\";i:1;s:11:\"show_author\";i:0;s:9:\"show_date\";i:1;}s:19:\"dashboard_secondary\";a:7:{s:4:\"link\";s:28:\"http://planet.wordpress.org/\";s:3:\"url\";s:33:\"http://planet.wordpress.org/feed/\";s:5:\"title\";s:20:\"Other WordPress News\";s:5:\"items\";i:5;s:12:\"show_summary\";i:0;s:11:\"show_author\";i:0;s:9:\"show_date\";i:0;}}','yes'),(119,0,'current_theme','Twenty Ten','yes'),(122,0,'_transient_doing_cron','1332156133','yes'),(132,0,'_transient_timeout_plugin_slugs','1325247715','no'),(133,0,'_transient_plugin_slugs','a:4:{i:0;s:19:\"akismet/akismet.php\";i:1;s:9:\"hello.php\";i:2;s:18:\"wp-unit/WPUnit.php\";i:3;s:27:\"wp_frontman/wp_frontman.php\";}','no'),(134,0,'recently_activated','a:0:{}','yes'),(147,0,'rewrite_rules','a:87:{s:48:\"categoria/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:43:\"categoria/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:36:\"categoria/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:18:\"categoria/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:29:\"comments/page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:74:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:69:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:62:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:44:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:61:\"date/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:56:\"date/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:49:\"date/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:31:\"date/([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:48:\"date/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:43:\"date/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:36:\"date/([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:18:\"date/([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:38:\".+?/[0-9]+/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:48:\".+?/[0-9]+/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:68:\".+?/[0-9]+/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\".+?/[0-9]+/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\".+?/[0-9]+/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"(.+?)/([0-9]+)/([^/]+)/trackback/?$\";s:71:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&tb=1\";s:55:\"(.+?)/([0-9]+)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:83:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&feed=$matches[4]\";s:50:\"(.+?)/([0-9]+)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:83:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&feed=$matches[4]\";s:43:\"(.+?)/([0-9]+)/([^/]+)/page/?([0-9]{1,})/?$\";s:84:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&paged=$matches[4]\";s:50:\"(.+?)/([0-9]+)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:84:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&cpage=$matches[4]\";s:35:\"(.+?)/([0-9]+)/([^/]+)(/[0-9]+)?/?$\";s:83:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&page=$matches[4]\";s:27:\".+?/[0-9]+/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".+?/[0-9]+/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".+?/[0-9]+/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".+?/[0-9]+/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".+?/[0-9]+/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:32:\".+?/[0-9]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\".+?/[0-9]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\".+?/[0-9]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\".+?/[0-9]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\".+?/[0-9]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"(.+?)/([0-9]+)/trackback/?$\";s:54:\"index.php?category_name=$matches[1]&p=$matches[2]&tb=1\";s:47:\"(.+?)/([0-9]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?category_name=$matches[1]&p=$matches[2]&feed=$matches[3]\";s:42:\"(.+?)/([0-9]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?category_name=$matches[1]&p=$matches[2]&feed=$matches[3]\";s:35:\"(.+?)/([0-9]+)/page/?([0-9]{1,})/?$\";s:67:\"index.php?category_name=$matches[1]&p=$matches[2]&paged=$matches[3]\";s:42:\"(.+?)/([0-9]+)/comment-page-([0-9]{1,})/?$\";s:67:\"index.php?category_name=$matches[1]&p=$matches[2]&cpage=$matches[3]\";s:27:\"(.+?)/([0-9]+)(/[0-9]+)?/?$\";s:66:\"index.php?category_name=$matches[1]&p=$matches[2]&page=$matches[3]\";s:21:\".+?/[0-9]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\".+?/[0-9]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\".+?/[0-9]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\".+?/[0-9]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\".+?/[0-9]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:33:\"(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:26:\"(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:33:\"(.+?)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&cpage=$matches[2]\";s:8:\"(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";}','yes'),(156,0,'wp_frontman','a:15:{s:17:\"custom_taxonomies\";a:1:{s:6:\"things\";a:13:{s:8:\"_builtin\";b:0;s:12:\"hierarchical\";b:1;s:5:\"label\";s:6:\"Things\";s:4:\"name\";s:6:\"things\";s:11:\"object_type\";a:1:{i:11;s:4:\"post\";}s:6:\"public\";b:1;s:9:\"query_var\";b:1;s:7:\"rewrite\";a:3:{s:4:\"slug\";s:6:\"things\";s:10:\"with_front\";b:1;s:12:\"hierarchical\";b:1;}s:21:\"update_count_callback\";s:23:\"_update_post_term_count\";s:5:\"count\";b:1;s:12:\"rewrite_slug\";s:6:\"things\";s:18:\"rewrite_with_front\";b:1;s:20:\"rewrite_hierarchical\";b:1;}}s:17:\"custom_post_types\";a:0:{}s:14:\"favicon_source\";s:5:\"httpd\";s:12:\"favicon_file\";s:69:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/2/files/favicon.ico\";s:13:\"robots_source\";s:5:\"httpd\";s:11:\"robots_file\";s:68:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/2/files/robots.txt\";s:7:\"rewrite\";a:8:{s:19:\"permalink_structure\";s:33:\"/%category%/%post_id%/%postname%/\";s:11:\"author_base\";s:6:\"author\";s:11:\"search_base\";s:6:\"search\";s:13:\"comments_base\";s:8:\"comments\";s:15:\"pagination_base\";s:4:\"page\";s:9:\"feed_base\";s:4:\"feed\";s:13:\"category_base\";s:9:\"categoria\";s:8:\"tag_base\";s:3:\"tag\";}s:5:\"cache\";a:3:{s:5:\"label\";s:5:\"Cache\";s:7:\"enabled\";b:1;s:8:\"endpoint\";s:30:\"http://mu.ludolo.it/wpf_cache/\";}s:12:\"preformatter\";a:7:{s:5:\"label\";s:13:\"Preformatting\";s:7:\"enabled\";b:0;s:6:\"max_id\";i:0;s:10:\"batch_size\";i:500;s:10:\"batch_done\";b:0;s:13:\"batch_running\";b:0;s:13:\"relative_urls\";b:1;}s:5:\"feeds\";a:6:{s:5:\"label\";s:16:\"Feed Redirection\";s:7:\"enabled\";b:0;s:6:\"target\";N;s:5:\"paths\";N;s:15:\"comments_target\";N;s:14:\"comments_paths\";s:0:\"\";}s:6:\"images\";a:3:{s:5:\"label\";s:6:\"Images\";s:7:\"enabled\";b:0;s:5:\"sizes\";a:0:{}}s:9:\"analytics\";a:6:{s:5:\"label\";s:16:\"Google Analytics\";s:5:\"token\";N;s:13:\"session_token\";N;s:12:\"account_name\";N;s:10:\"account_id\";N;s:6:\"filter\";N;}s:11:\"_db_version\";i:5;s:7:\"_t_init\";i:1331738421;s:7:\"_t_save\";i:1332156149;}','yes'),(157,0,'_transient_timeout_dirsize_cache','1331742022','no'),(158,0,'_transient_dirsize_cache','a:1:{s:58:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/2/files/\";a:1:{s:4:\"size\";b:0;}}','no');
/*!40000 ALTER TABLE `wp_2_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_postmeta`
--

DROP TABLE IF EXISTS `wp_2_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_postmeta`
--

LOCK TABLES `wp_2_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_2_postmeta` DISABLE KEYS */;
INSERT INTO `wp_2_postmeta` VALUES (1,2,'_wp_page_template','default');
/*!40000 ALTER TABLE `wp_2_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_posts`
--

DROP TABLE IF EXISTS `wp_2_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` text NOT NULL,
  `post_parent` bigint(20) unsigned DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_posts`
--

LOCK TABLES `wp_2_posts` WRITE;
/*!40000 ALTER TABLE `wp_2_posts` DISABLE KEYS */;
INSERT INTO `wp_2_posts` VALUES (1,1,'2011-03-29 10:37:15','2011-03-29 10:37:15','Welcome to <a href=\"http://localhost/\">WP Frontman Sites</a>. This is your first post. Edit or delete it, then start blogging!','Hello world!','','publish','open','open','','hello-world','','','2011-03-29 10:37:15','2011-03-29 10:37:15','',NULL,'http://localhost/blog2/?p=1',0,'post','',1),(2,1,'2011-03-29 10:37:15','2011-03-29 10:37:15','This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickies to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/blog2/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!','Sample Page','','publish','open','open','','sample-page','','','2011-03-29 10:37:15','2011-03-29 10:37:15','',NULL,'http://localhost/blog2/?page_id=2',0,'page','',0),(3,1,'2011-11-22 15:27:06','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2011-11-22 15:27:06','0000-00-00 00:00:00','',0,'http://mu.ludolo.it/blog2/?p=3',0,'post','',0);
/*!40000 ALTER TABLE `wp_2_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_term_relationships`
--

DROP TABLE IF EXISTS `wp_2_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_term_relationships`
--

LOCK TABLES `wp_2_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_2_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_2_term_relationships` VALUES (1,1,0),(1,2,0),(2,2,0),(3,2,0),(4,2,0),(5,2,0),(6,2,0),(7,2,0);
/*!40000 ALTER TABLE `wp_2_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_2_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`),
  KEY `wp_2_term_taxonomy_ibfk2` (`parent`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_term_taxonomy`
--

LOCK TABLES `wp_2_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_2_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_2_term_taxonomy` VALUES (1,1,'category','',NULL,1),(2,2,'link_category','',NULL,7),(3,3,'post_tag','',NULL,1);
/*!40000 ALTER TABLE `wp_2_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_2_terms`
--

DROP TABLE IF EXISTS `wp_2_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_2_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_2_terms`
--

LOCK TABLES `wp_2_terms` WRITE;
/*!40000 ALTER TABLE `wp_2_terms` DISABLE KEYS */;
INSERT INTO `wp_2_terms` VALUES (1,'Uncategorized','uncategorized',0),(2,'Blogroll','blogroll',0),(3,'tag5','tag5',0);
/*!40000 ALTER TABLE `wp_2_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_commentmeta`
--

DROP TABLE IF EXISTS `wp_3_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_commentmeta`
--

LOCK TABLES `wp_3_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_3_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_3_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_comments`
--

DROP TABLE IF EXISTS `wp_3_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_approved` (`comment_approved`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `wp_3_comments_ibfk1` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_comments`
--

LOCK TABLES `wp_3_comments` WRITE;
/*!40000 ALTER TABLE `wp_3_comments` DISABLE KEYS */;
INSERT INTO `wp_3_comments` VALUES (1,1,'Mr WordPress','','http://localhost/','','2011-03-29 10:37:34','2011-03-29 10:37:34','Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.',0,'1','','',NULL,NULL);
/*!40000 ALTER TABLE `wp_3_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_links`
--

DROP TABLE IF EXISTS `wp_3_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_links`
--

LOCK TABLES `wp_3_links` WRITE;
/*!40000 ALTER TABLE `wp_3_links` DISABLE KEYS */;
INSERT INTO `wp_3_links` VALUES (1,'http://codex.wordpress.org/','Documentation','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(2,'http://wordpress.org/news/','WordPress Blog','','','','Y',1,0,'0000-00-00 00:00:00','','','http://wordpress.org/news/feed/'),(3,'http://wordpress.org/extend/ideas/','Suggest Ideas','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(4,'http://wordpress.org/support/','Support Forum','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(5,'http://wordpress.org/extend/plugins/','Plugins','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(6,'http://wordpress.org/extend/themes/','Themes','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(7,'http://planet.wordpress.org/','WordPress Planet','','','','Y',1,0,'0000-00-00 00:00:00','','','');
/*!40000 ALTER TABLE `wp_3_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_options`
--

DROP TABLE IF EXISTS `wp_3_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_options`
--

LOCK TABLES `wp_3_options` WRITE;
/*!40000 ALTER TABLE `wp_3_options` DISABLE KEYS */;
INSERT INTO `wp_3_options` VALUES (1,0,'siteurl','http://mu.ludolo.it/blog3/','yes'),(2,0,'blogname','WP Frontman Blog 3','yes'),(3,0,'blogdescription','Just another WP Frontman Sites site','yes'),(4,0,'users_can_register','0','yes'),(5,0,'admin_email','ludo@qix.it','yes'),(6,0,'start_of_week','1','yes'),(7,0,'use_balanceTags','0','yes'),(8,0,'use_smilies','1','yes'),(9,0,'require_name_email','1','yes'),(10,0,'comments_notify','1','yes'),(11,0,'posts_per_rss','10','yes'),(12,0,'rss_use_excerpt','0','yes'),(13,0,'mailserver_url','mail.example.com','yes'),(14,0,'mailserver_login','login@example.com','yes'),(15,0,'mailserver_pass','password','yes'),(16,0,'mailserver_port','110','yes'),(17,0,'default_category','1','yes'),(18,0,'default_comment_status','open','yes'),(19,0,'default_ping_status','open','yes'),(20,0,'default_pingback_flag','1','yes'),(21,0,'default_post_edit_rows','20','yes'),(22,0,'posts_per_page','10','yes'),(23,0,'date_format','F j, Y','yes'),(24,0,'time_format','g:i a','yes'),(25,0,'links_updated_date_format','F j, Y g:i a','yes'),(26,0,'links_recently_updated_prepend','<em>','yes'),(27,0,'links_recently_updated_append','</em>','yes'),(28,0,'links_recently_updated_time','120','yes'),(29,0,'comment_moderation','0','yes'),(30,0,'moderation_notify','1','yes'),(31,0,'permalink_structure','/%category%/%postname%/','yes'),(32,0,'gzipcompression','0','yes'),(33,0,'hack_file','0','yes'),(34,0,'blog_charset','UTF-8','yes'),(35,0,'moderation_keys','','no'),(36,0,'active_plugins','a:0:{}','yes'),(37,0,'home','http://mu.ludolo.it/blog3/','yes'),(38,0,'category_base','','yes'),(39,0,'ping_sites','http://rpc.pingomatic.com/','yes'),(40,0,'advanced_edit','0','yes'),(41,0,'comment_max_links','2','yes'),(42,0,'gmt_offset','0','yes'),(43,0,'default_email_category','1','yes'),(44,0,'recently_edited','','no'),(45,0,'template','twentyten','yes'),(46,0,'stylesheet','twentyten','yes'),(47,0,'comment_whitelist','1','yes'),(48,0,'blacklist_keys','','no'),(49,0,'comment_registration','0','yes'),(50,0,'rss_language','en','yes'),(51,0,'html_type','text/html','yes'),(52,0,'use_trackback','0','yes'),(53,0,'default_role','subscriber','yes'),(54,0,'db_version','19470','yes'),(55,0,'uploads_use_yearmonth_folders','1','yes'),(56,0,'upload_path','wp-content/blogs.dir/3/files','yes'),(57,0,'blog_public','1','yes'),(58,0,'default_link_category','2','yes'),(59,0,'show_on_front','posts','yes'),(60,0,'tag_base','','yes'),(61,0,'show_avatars','1','yes'),(62,0,'avatar_rating','G','yes'),(63,0,'upload_url_path','','yes'),(64,0,'thumbnail_size_w','150','yes'),(65,0,'thumbnail_size_h','150','yes'),(66,0,'thumbnail_crop','1','yes'),(67,0,'medium_size_w','300','yes'),(68,0,'medium_size_h','300','yes'),(69,0,'avatar_default','mystery','yes'),(70,0,'enable_app','0','yes'),(71,0,'enable_xmlrpc','0','yes'),(72,0,'large_size_w','1024','yes'),(73,0,'large_size_h','1024','yes'),(74,0,'image_default_link_type','file','yes'),(75,0,'image_default_size','','yes'),(76,0,'image_default_align','','yes'),(77,0,'close_comments_for_old_posts','0','yes'),(78,0,'close_comments_days_old','14','yes'),(79,0,'thread_comments','1','yes'),(80,0,'thread_comments_depth','5','yes'),(81,0,'page_comments','0','yes'),(82,0,'comments_per_page','50','yes'),(83,0,'default_comments_page','newest','yes'),(84,0,'comment_order','asc','yes'),(85,0,'sticky_posts','a:0:{}','yes'),(86,0,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(87,0,'widget_text','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(88,0,'widget_rss','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(89,0,'timezone_string','','yes'),(90,0,'embed_autourls','1','yes'),(91,0,'embed_size_w','','yes'),(92,0,'embed_size_h','600','yes'),(93,0,'page_for_posts','0','yes'),(94,0,'page_on_front','0','yes'),(95,0,'default_post_format','0','yes'),(96,0,'wp_3_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes'),(97,0,'fileupload_url','http://mu.ludolo.it/blog3/files','yes'),(98,0,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(99,0,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(100,0,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(101,0,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(102,0,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(103,0,'sidebars_widgets','a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:19:\"primary-widget-area\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:21:\"secondary-widget-area\";a:0:{}s:24:\"first-footer-widget-area\";a:0:{}s:25:\"second-footer-widget-area\";a:0:{}s:24:\"third-footer-widget-area\";a:0:{}s:25:\"fourth-footer-widget-area\";a:0:{}s:13:\"array_version\";i:3;}','yes'),(105,0,'WPLANG','','yes'),(106,0,'db_upgraded','','yes'),(108,0,'widget_pages','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(109,0,'widget_calendar','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(110,0,'widget_links','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(111,0,'widget_tag_cloud','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(112,0,'widget_nav_menu','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(114,0,'cron','a:2:{i:1326298281;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}','yes'),(115,0,'dashboard_widget_options','a:4:{s:25:\"dashboard_recent_comments\";a:1:{s:5:\"items\";i:5;}s:24:\"dashboard_incoming_links\";a:5:{s:4:\"home\";s:25:\"http://mu.ludolo.it/blog3\";s:4:\"link\";s:101:\"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://mu.ludolo.it/blog3/\";s:3:\"url\";s:134:\"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://mu.ludolo.it/blog3/\";s:5:\"items\";i:10;s:9:\"show_date\";b:0;}s:17:\"dashboard_primary\";a:7:{s:4:\"link\";s:26:\"http://wordpress.org/news/\";s:3:\"url\";s:31:\"http://wordpress.org/news/feed/\";s:5:\"title\";s:14:\"WordPress Blog\";s:5:\"items\";i:2;s:12:\"show_summary\";i:1;s:11:\"show_author\";i:0;s:9:\"show_date\";i:1;}s:19:\"dashboard_secondary\";a:7:{s:4:\"link\";s:28:\"http://planet.wordpress.org/\";s:3:\"url\";s:33:\"http://planet.wordpress.org/feed/\";s:5:\"title\";s:20:\"Other WordPress News\";s:5:\"items\";i:5;s:12:\"show_summary\";i:0;s:11:\"show_author\";i:0;s:9:\"show_date\";i:0;}}','yes'),(116,0,'current_theme','Twenty Ten','yes'),(119,0,'_transient_doing_cron','1331738426','yes'),(135,0,'_transient_timeout_plugin_slugs','1325257626','no'),(136,0,'_transient_plugin_slugs','a:4:{i:0;s:19:\"akismet/akismet.php\";i:1;s:9:\"hello.php\";i:2;s:18:\"wp-unit/WPUnit.php\";i:3;s:27:\"wp_frontman/wp_frontman.php\";}','no'),(137,0,'recently_activated','a:0:{}','yes'),(140,0,'post_count','2','yes'),(148,0,'wp_frontman','a:15:{s:17:\"custom_taxonomies\";a:0:{}s:17:\"custom_post_types\";a:0:{}s:14:\"favicon_source\";s:5:\"httpd\";s:12:\"favicon_file\";s:69:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/3/files/favicon.ico\";s:13:\"robots_source\";s:5:\"httpd\";s:11:\"robots_file\";s:68:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/3/files/robots.txt\";s:7:\"rewrite\";a:8:{s:19:\"permalink_structure\";s:23:\"/%category%/%postname%/\";s:11:\"author_base\";s:6:\"author\";s:11:\"search_base\";s:6:\"search\";s:13:\"comments_base\";s:8:\"comments\";s:15:\"pagination_base\";s:4:\"page\";s:9:\"feed_base\";s:4:\"feed\";s:13:\"category_base\";s:0:\"\";s:8:\"tag_base\";s:0:\"\";}s:5:\"cache\";a:3:{s:5:\"label\";s:5:\"Cache\";s:7:\"enabled\";b:1;s:8:\"endpoint\";s:30:\"http://mu.ludolo.it/wpf_cache/\";}s:12:\"preformatter\";a:7:{s:5:\"label\";s:13:\"Preformatting\";s:7:\"enabled\";b:0;s:6:\"max_id\";i:0;s:10:\"batch_size\";i:500;s:10:\"batch_done\";b:0;s:13:\"batch_running\";b:0;s:13:\"relative_urls\";b:1;}s:5:\"feeds\";a:6:{s:5:\"label\";s:16:\"Feed Redirection\";s:7:\"enabled\";b:0;s:6:\"target\";N;s:5:\"paths\";N;s:15:\"comments_target\";N;s:14:\"comments_paths\";s:0:\"\";}s:6:\"images\";a:3:{s:5:\"label\";s:6:\"Images\";s:7:\"enabled\";b:0;s:5:\"sizes\";a:0:{}}s:9:\"analytics\";a:6:{s:5:\"label\";s:16:\"Google Analytics\";s:5:\"token\";N;s:13:\"session_token\";N;s:12:\"account_name\";N;s:10:\"account_id\";N;s:6:\"filter\";N;}s:11:\"_db_version\";i:5;s:7:\"_t_init\";i:1331738426;s:7:\"_t_save\";i:1331738426;}','yes'),(149,0,'rewrite_rules','a:71:{s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:29:\"comments/page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:31:\".+?/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\".+?/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:26:\"(.+?)/([^/]+)/trackback/?$\";s:57:\"index.php?category_name=$matches[1]&name=$matches[2]&tb=1\";s:46:\"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:41:\"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]\";s:34:\"(.+?)/([^/]+)/page/?([0-9]{1,})/?$\";s:70:\"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]\";s:41:\"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$\";s:70:\"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]\";s:26:\"(.+?)/([^/]+)(/[0-9]+)?/?$\";s:69:\"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]\";s:20:\".+?/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:30:\".+?/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:50:\".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:33:\"(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:26:\"(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:33:\"(.+?)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&cpage=$matches[2]\";s:8:\"(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";}','yes'),(150,0,'_transient_timeout_dirsize_cache','1331742026','no'),(151,0,'_transient_dirsize_cache','a:1:{s:58:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/3/files/\";a:1:{s:4:\"size\";b:0;}}','no');
/*!40000 ALTER TABLE `wp_3_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_postmeta`
--

DROP TABLE IF EXISTS `wp_3_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_postmeta`
--

LOCK TABLES `wp_3_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_3_postmeta` DISABLE KEYS */;
INSERT INTO `wp_3_postmeta` VALUES (1,2,'_wp_page_template','default'),(2,4,'_edit_last','1'),(3,4,'_edit_lock','1326270035:1');
/*!40000 ALTER TABLE `wp_3_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_posts`
--

DROP TABLE IF EXISTS `wp_3_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` text NOT NULL,
  `post_parent` bigint(20) unsigned DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_posts`
--

LOCK TABLES `wp_3_posts` WRITE;
/*!40000 ALTER TABLE `wp_3_posts` DISABLE KEYS */;
INSERT INTO `wp_3_posts` VALUES (1,1,'2011-03-29 10:37:34','2011-03-29 10:37:34','Welcome to <a href=\"http://localhost/\">WP Frontman Sites</a>. This is your first post. Edit or delete it, then start blogging!','Hello world!','','publish','open','open','','hello-world','','','2011-03-29 10:37:34','2011-03-29 10:37:34','\0<p>Welcome to <a href=\"http://localhost/\">WP Frontman Sites</a>. This is your first post. Edit or delete it, then start blogging!</p>\n\01301387854',NULL,'http://localhost/blog3/?p=1',0,'post','',1),(2,1,'2011-03-29 10:37:34','2011-03-29 10:37:34','This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickies to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/blog3/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!','Sample Page','','publish','open','open','','sample-page','','','2011-03-29 10:37:34','2011-03-29 10:37:34','\0<p>This is an example page. It&#8217;s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<blockquote><p>Hi there! I&#8217;m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin&#8217; caught in the rain.)</p></blockquote>\n<p>&#8230;or something like this:</p>\n<blockquote><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickies to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/blog3/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n\01301387854',NULL,'http://localhost/blog3/?page_id=2',0,'page','',0),(4,1,'2012-01-10 16:15:02','2012-01-10 16:15:02','Scheduled post text.','Scheduled post','','publish','open','open','','scheduled-post','','','2012-01-10 16:14:25','2012-01-10 16:14:25','',0,'http://mu.ludolo.it/blog3/?p=4',0,'post','',0),(5,1,'2012-01-10 16:14:10','2012-01-10 16:14:10','','Scheduled post','','inherit','open','open','','4-revision','','','2012-01-10 16:14:10','2012-01-10 16:14:10','',4,'http://mu.ludolo.it/blog3/uncategorized/4-revision/',0,'revision','',0),(6,1,'2012-01-10 16:15:26','2012-01-10 16:15:26','Scheduled post text.','Scheduled post','','inherit','open','open','','4-autosave','','','2012-01-10 16:15:26','2012-01-10 16:15:26','',4,'http://mu.ludolo.it/blog3/uncategorized/4-autosave/',0,'revision','',0),(7,1,'2012-03-14 15:20:26','0000-00-00 00:00:00','','Auto Draft','','auto-draft','open','open','','','','','2012-03-14 15:20:26','0000-00-00 00:00:00','',0,'http://mu.ludolo.it/blog3/?p=7',0,'post','',0);
/*!40000 ALTER TABLE `wp_3_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_term_relationships`
--

DROP TABLE IF EXISTS `wp_3_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_term_relationships`
--

LOCK TABLES `wp_3_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_3_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_3_term_relationships` VALUES (1,1,0),(1,2,0),(2,2,0),(3,2,0),(4,1,0),(4,2,0),(5,2,0),(6,2,0),(7,2,0);
/*!40000 ALTER TABLE `wp_3_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_3_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`),
  KEY `wp_3_term_taxonomy_ibfk2` (`parent`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_term_taxonomy`
--

LOCK TABLES `wp_3_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_3_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_3_term_taxonomy` VALUES (1,1,'category','',NULL,2),(2,2,'link_category','',NULL,7);
/*!40000 ALTER TABLE `wp_3_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_3_terms`
--

DROP TABLE IF EXISTS `wp_3_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_3_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_3_terms`
--

LOCK TABLES `wp_3_terms` WRITE;
/*!40000 ALTER TABLE `wp_3_terms` DISABLE KEYS */;
INSERT INTO `wp_3_terms` VALUES (1,'Uncategorized','uncategorized',0),(2,'Blogroll','blogroll',0);
/*!40000 ALTER TABLE `wp_3_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_commentmeta`
--

DROP TABLE IF EXISTS `wp_4_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_commentmeta`
--

LOCK TABLES `wp_4_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_4_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_4_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_comments`
--

DROP TABLE IF EXISTS `wp_4_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_approved` (`comment_approved`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_comments`
--

LOCK TABLES `wp_4_comments` WRITE;
/*!40000 ALTER TABLE `wp_4_comments` DISABLE KEYS */;
INSERT INTO `wp_4_comments` VALUES (1,1,'Mr WordPress','','http://localhost/','','2011-03-30 14:32:45','2011-03-30 14:32:45','Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.',0,'1','','',0,0);
/*!40000 ALTER TABLE `wp_4_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_links`
--

DROP TABLE IF EXISTS `wp_4_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_links`
--

LOCK TABLES `wp_4_links` WRITE;
/*!40000 ALTER TABLE `wp_4_links` DISABLE KEYS */;
INSERT INTO `wp_4_links` VALUES (1,'http://codex.wordpress.org/','Documentation','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(2,'http://wordpress.org/news/','WordPress Blog','','','','Y',1,0,'0000-00-00 00:00:00','','','http://wordpress.org/news/feed/'),(3,'http://wordpress.org/extend/ideas/','Suggest Ideas','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(4,'http://wordpress.org/support/','Support Forum','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(5,'http://wordpress.org/extend/plugins/','Plugins','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(6,'http://wordpress.org/extend/themes/','Themes','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(7,'http://planet.wordpress.org/','WordPress Planet','','','','Y',1,0,'0000-00-00 00:00:00','','','');
/*!40000 ALTER TABLE `wp_4_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_options`
--

DROP TABLE IF EXISTS `wp_4_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_options`
--

LOCK TABLES `wp_4_options` WRITE;
/*!40000 ALTER TABLE `wp_4_options` DISABLE KEYS */;
INSERT INTO `wp_4_options` VALUES (1,0,'siteurl','http://localhost/a/','yes'),(2,0,'blogname','Test','yes'),(3,0,'blogdescription','Just another WP Frontman Sites site','yes'),(4,0,'users_can_register','0','yes'),(5,0,'admin_email','ludo@qix.it','yes'),(6,0,'start_of_week','1','yes'),(7,0,'use_balanceTags','0','yes'),(8,0,'use_smilies','1','yes'),(9,0,'require_name_email','1','yes'),(10,0,'comments_notify','1','yes'),(11,0,'posts_per_rss','10','yes'),(12,0,'rss_use_excerpt','0','yes'),(13,0,'mailserver_url','mail.example.com','yes'),(14,0,'mailserver_login','login@example.com','yes'),(15,0,'mailserver_pass','password','yes'),(16,0,'mailserver_port','110','yes'),(17,0,'default_category','1','yes'),(18,0,'default_comment_status','open','yes'),(19,0,'default_ping_status','open','yes'),(20,0,'default_pingback_flag','1','yes'),(21,0,'default_post_edit_rows','10','yes'),(22,0,'posts_per_page','10','yes'),(23,0,'date_format','F j, Y','yes'),(24,0,'time_format','g:i a','yes'),(25,0,'links_updated_date_format','F j, Y g:i a','yes'),(26,0,'links_recently_updated_prepend','<em>','yes'),(27,0,'links_recently_updated_append','</em>','yes'),(28,0,'links_recently_updated_time','120','yes'),(29,0,'comment_moderation','0','yes'),(30,0,'moderation_notify','1','yes'),(31,0,'permalink_structure','/%year%/%monthnum%/%day%/%postname%/','yes'),(32,0,'gzipcompression','0','yes'),(33,0,'hack_file','0','yes'),(34,0,'blog_charset','UTF-8','yes'),(35,0,'moderation_keys','','no'),(36,0,'active_plugins','a:0:{}','yes'),(37,0,'home','http://localhost/a/','yes'),(38,0,'category_base','','yes'),(39,0,'ping_sites','http://rpc.pingomatic.com/','yes'),(40,0,'advanced_edit','0','yes'),(41,0,'comment_max_links','2','yes'),(42,0,'gmt_offset','0','yes'),(43,0,'default_email_category','1','yes'),(44,0,'recently_edited','','no'),(45,0,'template','twentyten','yes'),(46,0,'stylesheet','twentyten','yes'),(47,0,'comment_whitelist','1','yes'),(48,0,'blacklist_keys','','no'),(49,0,'comment_registration','0','yes'),(50,0,'rss_language','en','yes'),(51,0,'html_type','text/html','yes'),(52,0,'use_trackback','0','yes'),(53,0,'default_role','subscriber','yes'),(54,0,'db_version','15477','yes'),(55,0,'uploads_use_yearmonth_folders','1','yes'),(56,0,'upload_path','wp-content/blogs.dir/4/files','yes'),(57,0,'blog_public','1','yes'),(58,0,'default_link_category','2','yes'),(59,0,'show_on_front','posts','yes'),(60,0,'tag_base','','yes'),(61,0,'show_avatars','1','yes'),(62,0,'avatar_rating','G','yes'),(63,0,'upload_url_path','','yes'),(64,0,'thumbnail_size_w','150','yes'),(65,0,'thumbnail_size_h','150','yes'),(66,0,'thumbnail_crop','1','yes'),(67,0,'medium_size_w','300','yes'),(68,0,'medium_size_h','300','yes'),(69,0,'avatar_default','mystery','yes'),(70,0,'enable_app','0','yes'),(71,0,'enable_xmlrpc','0','yes'),(72,0,'large_size_w','1024','yes'),(73,0,'large_size_h','1024','yes'),(74,0,'image_default_link_type','file','yes'),(75,0,'image_default_size','','yes'),(76,0,'image_default_align','','yes'),(77,0,'close_comments_for_old_posts','0','yes'),(78,0,'close_comments_days_old','14','yes'),(79,0,'thread_comments','1','yes'),(80,0,'thread_comments_depth','5','yes'),(81,0,'page_comments','0','yes'),(82,0,'comments_per_page','50','yes'),(83,0,'default_comments_page','newest','yes'),(84,0,'comment_order','asc','yes'),(85,0,'sticky_posts','a:0:{}','yes'),(86,0,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(87,0,'widget_text','a:0:{}','yes'),(88,0,'widget_rss','a:0:{}','yes'),(89,0,'timezone_string','','yes'),(90,0,'embed_autourls','1','yes'),(91,0,'embed_size_w','','yes'),(92,0,'embed_size_h','600','yes'),(93,0,'page_for_posts','0','yes'),(94,0,'page_on_front','0','yes'),(95,0,'wp_4_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes'),(96,0,'fileupload_url','http://localhost/a/files','yes'),(97,0,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(98,0,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(99,0,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(100,0,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(101,0,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(102,0,'sidebars_widgets','a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:19:\"primary-widget-area\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:21:\"secondary-widget-area\";a:0:{}s:24:\"first-footer-widget-area\";a:0:{}s:25:\"second-footer-widget-area\";a:0:{}s:24:\"third-footer-widget-area\";a:0:{}s:25:\"fourth-footer-widget-area\";a:0:{}s:13:\"array_version\";i:3;}','yes'),(103,0,'rewrite_rules','a:72:{s:14:\".*wp-atom.php$\";s:19:\"index.php?feed=atom\";s:13:\".*wp-rdf.php$\";s:18:\"index.php?feed=rdf\";s:13:\".*wp-rss.php$\";s:18:\"index.php?feed=rss\";s:14:\".*wp-rss2.php$\";s:19:\"index.php?feed=rss2\";s:14:\".*wp-feed.php$\";s:19:\"index.php?feed=feed\";s:22:\".*wp-commentsrss2.php$\";s:34:\"index.php?feed=rss2&withcomments=1\";s:16:\".*wp-signup.php$\";s:21:\"index.php?signup=true\";s:18:\".*wp-activate.php$\";s:23:\"index.php?activate=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:29:\"comments/page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:42:\"tag/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:37:\"tag/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:30:\"tag/(.+?)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:12:\"tag/(.+?)/?$\";s:25:\"index.php?tag=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:25:\".+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\".+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\".+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\".+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\".+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:18:\"(.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:38:\"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:33:\"(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:26:\"(.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:33:\"(.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:18:\"(.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}','yes'),(104,0,'WPLANG','','yes');
/*!40000 ALTER TABLE `wp_4_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_postmeta`
--

DROP TABLE IF EXISTS `wp_4_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_postmeta`
--

LOCK TABLES `wp_4_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_4_postmeta` DISABLE KEYS */;
INSERT INTO `wp_4_postmeta` VALUES (1,2,'_wp_page_template','default');
/*!40000 ALTER TABLE `wp_4_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_posts`
--

DROP TABLE IF EXISTS `wp_4_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` text NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_posts`
--

LOCK TABLES `wp_4_posts` WRITE;
/*!40000 ALTER TABLE `wp_4_posts` DISABLE KEYS */;
INSERT INTO `wp_4_posts` VALUES (1,1,'2011-03-30 14:32:45','2011-03-30 14:32:45','Welcome to <a href=\"http://localhost/\">WP Frontman Sites</a>. This is your first post. Edit or delete it, then start blogging!','Hello world!','','publish','open','open','','hello-world','','','2011-03-30 14:32:45','2011-03-30 14:32:45','',0,'http://localhost/a/?p=1',0,'post','',1),(2,1,'2011-03-30 14:32:45','2011-03-30 14:32:45','This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.','About','','publish','open','open','','about','','','2011-03-30 14:32:45','2011-03-30 14:32:45','',0,'http://localhost/a/?page_id=2',0,'page','',0);
/*!40000 ALTER TABLE `wp_4_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_term_relationships`
--

DROP TABLE IF EXISTS `wp_4_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_term_relationships`
--

LOCK TABLES `wp_4_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_4_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_4_term_relationships` VALUES (1,1,0),(1,2,0),(2,2,0),(3,2,0),(4,2,0),(5,2,0),(6,2,0),(7,2,0);
/*!40000 ALTER TABLE `wp_4_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_4_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_term_taxonomy`
--

LOCK TABLES `wp_4_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_4_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_4_term_taxonomy` VALUES (1,1,'category','',0,1),(2,2,'link_category','',0,7);
/*!40000 ALTER TABLE `wp_4_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_4_terms`
--

DROP TABLE IF EXISTS `wp_4_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_4_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_4_terms`
--

LOCK TABLES `wp_4_terms` WRITE;
/*!40000 ALTER TABLE `wp_4_terms` DISABLE KEYS */;
INSERT INTO `wp_4_terms` VALUES (1,'Uncategorized','uncategorized',0),(2,'Blogroll','blogroll',0);
/*!40000 ALTER TABLE `wp_4_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_blog_versions`
--

DROP TABLE IF EXISTS `wp_blog_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_blog_versions`
--

LOCK TABLES `wp_blog_versions` WRITE;
/*!40000 ALTER TABLE `wp_blog_versions` DISABLE KEYS */;
INSERT INTO `wp_blog_versions` VALUES (1,'19470','2011-03-30 10:11:56'),(2,'19470','2011-03-30 10:12:40'),(3,'19470','2011-03-30 10:12:35');
/*!40000 ALTER TABLE `wp_blog_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_blogs`
--

DROP TABLE IF EXISTS `wp_blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` enum('0','1') NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_blogs`
--

LOCK TABLES `wp_blogs` WRITE;
/*!40000 ALTER TABLE `wp_blogs` DISABLE KEYS */;
INSERT INTO `wp_blogs` VALUES (1,1,'mu.ludolo.it','/','2011-03-29 10:35:04','2011-09-19 09:12:15',1,'0',0,0,0,0),(2,1,'mu.ludolo.it','/blog2/','2011-03-29 10:37:11','2011-03-30 14:03:28',1,'0',0,0,0,0),(3,1,'mu.ludolo.it','/blog3/','2011-03-29 10:37:31','2012-01-10 16:46:07',1,'0',0,0,0,0);
/*!40000 ALTER TABLE `wp_blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_commentmeta`
--

DROP TABLE IF EXISTS `wp_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_commentmeta`
--

LOCK TABLES `wp_commentmeta` WRITE;
/*!40000 ALTER TABLE `wp_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_comments`
--

DROP TABLE IF EXISTS `wp_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned DEFAULT '0',
  `user_id` bigint(20) unsigned DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_approved` (`comment_approved`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `wp_comments_ibfk1` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_comments`
--

LOCK TABLES `wp_comments` WRITE;
/*!40000 ALTER TABLE `wp_comments` DISABLE KEYS */;
INSERT INTO `wp_comments` VALUES (2,5,'ludo','ludo@qix.it','','127.0.0.1','2011-04-01 10:56:06','2011-04-01 08:56:06','Test.',0,'1','Django test framework','',NULL,NULL),(8,5,'ludo','ludo@qix.it','','127.0.0.1','2011-04-01 11:06:17','2011-04-01 09:06:17','Test.',0,'1','Django test framework','',NULL,NULL),(9,5,'ludo','ludo@qix.it','','127.0.0.1','2011-04-01 11:07:41','2011-04-01 09:07:41','Test.',0,'1','Django test framework','',NULL,NULL),(10,5,'ludo','ludo@qix.it','','127.0.0.1','2011-04-01 11:08:20','2011-04-01 09:08:20','Test.',0,'1','Django test framework','',NULL,NULL),(11,5,'ludo','ludo@qix.it','','127.0.0.1','2011-04-01 11:09:18','2011-04-01 09:09:18','Test.',0,'1','Django test framework','',NULL,NULL),(12,5,'ludo','ludo@qix.it','','127.0.0.1','2011-04-01 11:12:38','2011-04-01 09:12:38','Test.',0,'1','Django test framework','',NULL,NULL),(13,5,'ludo','ludo@qix.it','','127.0.0.1','2011-04-01 15:34:36','2011-04-01 13:34:36','Test.',0,'1','Django test framework','',NULL,NULL),(14,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:44:40','2011-06-16 08:44:40','Test.',0,'1','Django test framework','',NULL,NULL),(15,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:45:01','2011-06-16 08:45:01','Test.',0,'1','Django test framework','',NULL,NULL),(16,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:45:30','2011-06-16 08:45:30','Test.',0,'1','Django test framework','',NULL,NULL),(17,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:47:36','2011-06-16 08:47:36','Test.',0,'1','Django test framework','',NULL,NULL),(18,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:47:44','2011-06-16 08:47:44','Test.',0,'1','Django test framework','',NULL,NULL),(19,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:48:59','2011-06-16 08:48:59','Test.',0,'1','Django test framework','',NULL,NULL),(20,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:49:15','2011-06-16 08:49:15','Test.',0,'1','Django test framework','',NULL,NULL),(21,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:49:28','2011-06-16 08:49:28','Test.',0,'1','Django test framework','',NULL,NULL),(22,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:49:39','2011-06-16 08:49:39','Test.',0,'1','Django test framework','',NULL,NULL),(23,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:52:42','2011-06-16 08:52:42','Test.',0,'1','Django test framework','',NULL,NULL),(24,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:53:46','2011-06-16 08:53:46','Test.',0,'1','Django test framework','',NULL,NULL),(25,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:54:11','2011-06-16 08:54:11','Test.',0,'1','Django test framework','',NULL,NULL),(26,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:54:19','2011-06-16 08:54:19','Test.',0,'1','Django test framework','',NULL,NULL),(27,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:55:33','2011-06-16 08:55:33','Test.',0,'1','Django test framework','',NULL,NULL),(28,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:56:40','2011-06-16 08:56:40','Test.',0,'1','Django test framework','',NULL,NULL),(29,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:57:04','2011-06-16 08:57:04','Test.',0,'1','Django test framework','',NULL,NULL),(30,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 10:57:14','2011-06-16 08:57:14','Test.',0,'1','Django test framework','',NULL,NULL),(31,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:00:20','2011-06-16 09:00:20','Test.',0,'1','Django test framework','',NULL,NULL),(32,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:02:18','2011-06-16 09:02:18','Test.',0,'1','Django test framework','',NULL,NULL),(33,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:02:28','2011-06-16 09:02:28','Test.',0,'1','Django test framework','',NULL,NULL),(34,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:02:59','2011-06-16 09:02:59','Test.',0,'1','Django test framework','',NULL,NULL),(35,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:03:12','2011-06-16 09:03:12','Test.',0,'1','Django test framework','',NULL,NULL),(36,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:03:37','2011-06-16 09:03:37','Test.',0,'1','Django test framework','',NULL,NULL),(37,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:03:53','2011-06-16 09:03:53','Test.',0,'1','Django test framework','',NULL,NULL),(38,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:04:57','2011-06-16 09:04:57','Test.',0,'1','Django test framework','',NULL,NULL),(39,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:05:18','2011-06-16 09:05:18','Test.',0,'1','Django test framework','',NULL,NULL),(40,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:06:04','2011-06-16 09:06:04','Test.',0,'1','Django test framework','',NULL,NULL),(41,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:07:29','2011-06-16 09:07:29','Test.',0,'1','Django test framework','',NULL,NULL),(42,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:07:55','2011-06-16 09:07:55','Test.',0,'1','Django test framework','',NULL,NULL),(43,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:08:44','2011-06-16 09:08:44','Test.',0,'1','Django test framework','',NULL,NULL),(44,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:11:59','2011-06-16 09:11:59','Test.',0,'1','Django test framework','',NULL,NULL),(45,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:12:21','2011-06-16 09:12:21','Test.',0,'1','Django test framework','',NULL,NULL),(46,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:12:29','2011-06-16 09:12:29','Test.',0,'1','Django test framework','',NULL,NULL),(47,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:13:31','2011-06-16 09:13:31','Test.',0,'1','Django test framework','',NULL,NULL),(48,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:13:51','2011-06-16 09:13:51','Test.',0,'1','Django test framework','',NULL,NULL),(49,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:14:16','2011-06-16 09:14:16','Test.',0,'1','Django test framework','',NULL,NULL),(50,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:14:29','2011-06-16 09:14:29','Test.',0,'1','Django test framework','',NULL,NULL),(51,5,'ludo','ludo@qix.it','','127.0.0.1','2011-06-16 11:14:33','2011-06-16 09:14:33','Test.',0,'1','Django test framework','',NULL,NULL),(52,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 21:31:19','2011-07-13 19:31:19','Test.',0,'1','Django test framework','',NULL,NULL),(53,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 21:32:01','2011-07-13 19:32:01','Test.',0,'1','Django test framework','',NULL,NULL),(54,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 21:32:39','2011-07-13 19:32:39','Test.',0,'1','Django test framework','',NULL,NULL),(55,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:20:02','2011-07-13 20:20:02','Test.',0,'1','Django test framework','',NULL,NULL),(56,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:20:28','2011-07-13 20:20:28','Test.',0,'1','Django test framework','',NULL,NULL),(57,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:20:45','2011-07-13 20:20:45','Test.',0,'1','Django test framework','',NULL,NULL),(58,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:21:04','2011-07-13 20:21:04','Test.',0,'1','Django test framework','',NULL,NULL),(59,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:21:31','2011-07-13 20:21:31','Test.',0,'1','Django test framework','',NULL,NULL),(60,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:22:44','2011-07-13 20:22:44','Test.',0,'1','Django test framework','',NULL,NULL),(61,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:23:26','2011-07-13 20:23:26','Test.',0,'1','Django test framework','',NULL,NULL),(62,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:27:41','2011-07-13 20:27:41','Test.',0,'1','Django test framework','',NULL,NULL),(63,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:28:17','2011-07-13 20:28:17','Test.',0,'1','Django test framework','',NULL,NULL),(64,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:29:41','2011-07-13 20:29:41','Test.',0,'1','Django test framework','',NULL,NULL),(65,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:29:47','2011-07-13 20:29:47','Test.',0,'1','Django test framework','',NULL,NULL),(66,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:29:56','2011-07-13 20:29:56','Test.',0,'1','Django test framework','',NULL,NULL),(67,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:30:11','2011-07-13 20:30:11','Test.',0,'1','Django test framework','',NULL,NULL),(68,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:38:58','2011-07-13 20:38:58','Test.',0,'1','Django test framework','',NULL,NULL),(69,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:39:40','2011-07-13 20:39:40','Test.',0,'1','Django test framework','',NULL,NULL),(70,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:39:58','2011-07-13 20:39:58','Test.',0,'1','Django test framework','',NULL,NULL),(71,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:41:39','2011-07-13 20:41:39','Test.',0,'1','Django test framework','',NULL,NULL),(72,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:45:37','2011-07-13 20:45:37','Test.',0,'1','Django test framework','',0,0),(73,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:46:18','2011-07-13 20:46:18','Test.',0,'1','Django test framework','',0,0),(74,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:46:34','2011-07-13 20:46:34','Test.',0,'1','Django test framework','',0,0),(75,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:48:06','2011-07-13 20:48:06','Test.',0,'1','Django test framework','',0,0),(76,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:48:28','2011-07-13 20:48:28','Test.',0,'1','Django test framework','',0,0),(77,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:48:47','2011-07-13 20:48:47','Test.',0,'1','Django test framework','',0,0),(78,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:49:21','2011-07-13 20:49:21','Test.',0,'1','Django test framework','',0,0),(79,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:49:42','2011-07-13 20:49:42','Test.',0,'1','Django test framework','',0,0),(80,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:50:50','2011-07-13 20:50:50','Test.',0,'1','Django test framework','',0,0),(81,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-13 22:51:20','2011-07-13 20:51:20','Test.',0,'1','Django test framework','',0,0),(82,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:23:25','2011-07-14 09:23:25','Test.',0,'1','Django test framework','',0,0),(83,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:23:36','2011-07-14 09:23:36','Test.',0,'1','Django test framework','',0,0),(84,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:23:52','2011-07-14 09:23:52','Test.',0,'1','Django test framework','',0,0),(85,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:24:58','2011-07-14 09:24:58','Test.',0,'1','Django test framework','',0,0),(86,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:25:08','2011-07-14 09:25:08','Test.',0,'1','Django test framework','',0,0),(87,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:27:06','2011-07-14 09:27:06','Test.',0,'1','Django test framework','',0,0),(88,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:28:15','2011-07-14 09:28:15','Test.',0,'1','Django test framework','',0,0),(89,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:28:33','2011-07-14 09:28:33','Test.',0,'1','Django test framework','',0,0),(90,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:28:51','2011-07-14 09:28:51','Test.',0,'1','Django test framework','',0,0),(91,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:29:03','2011-07-14 09:29:03','Test.',0,'1','Django test framework','',0,0),(92,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:29:26','2011-07-14 09:29:26','Test.',0,'1','Django test framework','',0,0),(93,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:29:59','2011-07-14 09:29:59','Test.',0,'1','Django test framework','',0,0),(94,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:30:07','2011-07-14 09:30:07','Test.',0,'1','Django test framework','',0,0),(95,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:30:25','2011-07-14 09:30:25','Test.',0,'1','Django test framework','',0,0),(96,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:30:45','2011-07-14 09:30:45','Test.',0,'1','Django test framework','',0,0),(97,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:32:47','2011-07-14 09:32:47','Test.',0,'1','Django test framework','',0,0),(98,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:33:04','2011-07-14 09:33:04','Test.',0,'1','Django test framework','',0,0),(99,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:33:18','2011-07-14 09:33:18','Test.',0,'1','Django test framework','',0,0),(100,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:33:27','2011-07-14 09:33:27','Test.',0,'1','Django test framework','',0,0),(101,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:33:44','2011-07-14 09:33:44','Test.',0,'1','Django test framework','',0,0),(102,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-14 11:34:24','2011-07-14 09:34:24','Test.',0,'1','Django test framework','',0,0),(103,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-16 13:49:57','2011-07-16 11:49:57','Test.',0,'1','Django test framework','',0,0),(104,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-16 14:14:20','2011-07-16 12:14:20','Test.',0,'1','Django test framework','',0,0),(105,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 13:59:33','2011-07-17 11:59:33','Test.',0,'1','Django test framework','',0,0),(106,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:00:15','2011-07-17 12:00:15','Test.',0,'1','Django test framework','',0,0),(107,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:00:35','2011-07-17 12:00:35','Test.',0,'1','Django test framework','',0,0),(108,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:01:33','2011-07-17 12:01:33','Test.',0,'1','Django test framework','',0,0),(109,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:06:20','2011-07-17 12:06:20','Test.',0,'1','Django test framework','',0,0),(110,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:06:38','2011-07-17 12:06:38','Test.',0,'1','Django test framework','',0,0),(111,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:08:00','2011-07-17 12:08:00','Test.',0,'1','Django test framework','',0,0),(112,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:08:14','2011-07-17 12:08:14','Test.',0,'1','Django test framework','',0,0),(113,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:09:14','2011-07-17 12:09:14','Test.',0,'1','Django test framework','',0,0),(114,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:10:10','2011-07-17 12:10:10','Test.',0,'1','Django test framework','',0,0),(115,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:10:46','2011-07-17 12:10:46','Test.',0,'1','Django test framework','',0,0),(116,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:10:53','2011-07-17 12:10:53','Test.',0,'1','Django test framework','',0,0),(117,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:13:37','2011-07-17 12:13:37','Test.',0,'1','Django test framework','',0,0),(118,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:14:01','2011-07-17 12:14:01','Test.',0,'1','Django test framework','',0,0),(119,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:14:21','2011-07-17 12:14:21','Test.',0,'1','Django test framework','',0,0),(120,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:14:38','2011-07-17 12:14:38','Test.',0,'1','Django test framework','',0,0),(121,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:14:53','2011-07-17 12:14:53','Test.',0,'1','Django test framework','',0,0),(122,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:15:11','2011-07-17 12:15:11','Test.',0,'1','Django test framework','',0,0),(123,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:15:45','2011-07-17 12:15:45','Test.',0,'1','Django test framework','',0,0),(124,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:15:57','2011-07-17 12:15:57','Test.',0,'1','Django test framework','',0,0),(125,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:16:37','2011-07-17 12:16:37','Test.',0,'1','Django test framework','',0,0),(126,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:17:06','2011-07-17 12:17:06','Test.',0,'1','Django test framework','',0,0),(127,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-17 14:17:19','2011-07-17 12:17:19','Test.',0,'1','Django test framework','',0,0),(128,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 15:51:14','2011-07-18 13:51:14','Test.',0,'1','Django test framework','',0,0),(129,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 15:55:10','2011-07-18 13:55:10','Test.',0,'1','Django test framework','',0,0),(130,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 15:56:17','2011-07-18 13:56:17','Test.',0,'1','Django test framework','',0,0),(131,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 15:56:38','2011-07-18 13:56:38','Test.',0,'1','Django test framework','',0,0),(132,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:35:17','2011-07-18 14:35:17','Test.',0,'1','Django test framework','',0,0),(133,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:36:02','2011-07-18 14:36:02','Test.',0,'1','Django test framework','',0,0),(134,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:36:24','2011-07-18 14:36:24','Test.',0,'1','Django test framework','',0,0),(135,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:37:14','2011-07-18 14:37:14','Test.',0,'1','Django test framework','',0,0),(136,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:37:31','2011-07-18 14:37:31','Test.',0,'1','Django test framework','',0,0),(137,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:37:59','2011-07-18 14:37:59','Test.',0,'1','Django test framework','',0,0),(138,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:38:52','2011-07-18 14:38:52','Test.',0,'1','Django test framework','',0,0),(139,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:39:21','2011-07-18 14:39:21','Test.',0,'1','Django test framework','',0,0),(140,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:39:33','2011-07-18 14:39:33','Test.',0,'1','Django test framework','',0,0),(141,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:40:16','2011-07-18 14:40:16','Test.',0,'1','Django test framework','',0,0),(142,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:40:28','2011-07-18 14:40:28','Test.',0,'1','Django test framework','',0,0),(143,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:41:24','2011-07-18 14:41:24','Test.',0,'1','Django test framework','',0,0),(144,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:41:53','2011-07-18 14:41:53','Test.',0,'1','Django test framework','',0,0),(145,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:44:19','2011-07-18 14:44:19','Test.',0,'1','Django test framework','',0,0),(146,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:44:36','2011-07-18 14:44:36','Test.',0,'1','Django test framework','',0,0),(147,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:45:05','2011-07-18 14:45:05','Test.',0,'1','Django test framework','',0,0),(148,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:45:21','2011-07-18 14:45:21','Test.',0,'1','Django test framework','',0,0),(149,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 16:55:05','2011-07-18 14:55:05','Test.',0,'1','Django test framework','',0,0),(150,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:02:42','2011-07-18 15:02:42','Test.',0,'1','Django test framework','',0,0),(151,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:04:11','2011-07-18 15:04:11','Test.',0,'1','Django test framework','',0,0),(152,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:05:10','2011-07-18 15:05:10','Test.',0,'1','Django test framework','',0,0),(153,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:06:05','2011-07-18 15:06:05','Test.',0,'1','Django test framework','',0,0),(154,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:06:20','2011-07-18 15:06:20','Test.',0,'1','Django test framework','',0,0),(155,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:06:53','2011-07-18 15:06:53','Test.',0,'1','Django test framework','',0,0),(156,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:08:35','2011-07-18 15:08:35','Test.',0,'1','Django test framework','',0,0),(157,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:10:14','2011-07-18 15:10:14','Test.',0,'1','Django test framework','',0,0),(158,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:10:36','2011-07-18 15:10:36','Test.',0,'1','Django test framework','',0,0),(159,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:10:44','2011-07-18 15:10:44','Test.',0,'1','Django test framework','',0,0),(160,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:11:13','2011-07-18 15:11:13','Test.',0,'1','Django test framework','',0,0),(161,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:12:12','2011-07-18 15:12:12','Test.',0,'1','Django test framework','',0,0),(162,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:12:44','2011-07-18 15:12:44','Test.',0,'1','Django test framework','',0,0),(163,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:13:07','2011-07-18 15:13:07','Test.',0,'1','Django test framework','',0,0),(164,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-18 17:13:42','2011-07-18 15:13:42','Test.',0,'1','Django test framework','',0,0),(165,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 12:54:32','2011-07-19 10:54:32','Test.',0,'1','Django test framework','',0,0),(166,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 12:55:21','2011-07-19 10:55:21','Test.',0,'1','Django test framework','',0,0),(167,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 12:57:01','2011-07-19 10:57:01','Test.',0,'1','Django test framework','',0,0),(168,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 12:59:12','2011-07-19 10:59:12','Test.',0,'1','Django test framework','',0,0),(169,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 12:59:25','2011-07-19 10:59:25','Test.',0,'1','Django test framework','',0,0),(170,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:00:04','2011-07-19 11:00:04','Test.',0,'1','Django test framework','',0,0),(171,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:01:02','2011-07-19 11:01:02','Test.',0,'1','Django test framework','',0,0),(172,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:01:34','2011-07-19 11:01:34','Test.',0,'1','Django test framework','',0,0),(173,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:01:47','2011-07-19 11:01:47','Test.',0,'1','Django test framework','',0,0),(174,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:01:58','2011-07-19 11:01:58','Test.',0,'1','Django test framework','',0,0),(175,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:02:17','2011-07-19 11:02:17','Test.',0,'1','Django test framework','',0,0),(176,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:03:16','2011-07-19 11:03:16','Test.',0,'1','Django test framework','',0,0),(177,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:04:48','2011-07-19 11:04:48','Test.',0,'1','Django test framework','',0,0),(178,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:06:12','2011-07-19 11:06:12','Test.',0,'1','Django test framework','',0,0),(179,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:07:16','2011-07-19 11:07:16','Test.',0,'1','Django test framework','',0,0),(180,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:07:26','2011-07-19 11:07:26','Test.',0,'1','Django test framework','',0,0),(181,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:13:38','2011-07-19 11:13:38','Test.',0,'1','Django test framework','',0,0),(182,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:13:54','2011-07-19 11:13:54','Test.',0,'1','Django test framework','',0,0),(183,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:22:56','2011-07-19 11:22:56','Test.',0,'1','Django test framework','',0,0),(184,5,'ludo','ludo@qix.it','','127.0.0.1','2011-07-19 13:23:16','2011-07-19 11:23:16','Test.',0,'1','Django test framework','',0,0),(186,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:29:50','2011-08-15 10:29:50','Test.',0,'1','Django test framework','',0,0),(187,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:37:48','2011-08-15 10:37:48','Test.',0,'1','Django test framework','',0,0),(188,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:38:43','2011-08-15 10:38:43','Test.',0,'1','Django test framework','',0,0),(189,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:38:50','2011-08-15 10:38:50','Test.',0,'1','Django test framework','',0,0),(190,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:40:28','2011-08-15 10:40:28','Test.',0,'1','Django test framework','',0,0),(191,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:41:06','2011-08-15 10:41:06','Test.',0,'1','Django test framework','',0,0),(192,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:42:35','2011-08-15 10:42:35','Test.',0,'1','Django test framework','',0,0),(193,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:42:46','2011-08-15 10:42:46','Test.',0,'1','Django test framework','',0,0),(194,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:43:12','2011-08-15 10:43:12','Test.',0,'1','Django test framework','',0,0),(195,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:43:53','2011-08-15 10:43:53','Test.',0,'1','Django test framework','',0,0),(196,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:44:18','2011-08-15 10:44:18','Test.',0,'1','Django test framework','',0,0),(197,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-15 12:44:45','2011-08-15 10:44:45','Test.',0,'1','Django test framework','',0,0),(198,5,'ludo','ludo@qix.it','','127.0.0.1','2011-08-18 16:35:38','2011-08-18 14:35:38','Test.',0,'1','Django test framework','',0,0),(200,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-13 17:13:54','2011-09-13 15:13:54','Test.',0,'1','Django test framework','',0,0),(201,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-13 17:19:43','2011-09-13 15:19:43','Test.',0,'1','Django test framework','',0,0),(202,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-16 15:12:06','2011-09-16 13:12:06','Test.',0,'1','Django test framework','',0,0),(204,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-16 16:26:05','2011-09-16 14:26:05','Test.',0,'1','Django test framework','',0,0),(205,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-16 16:27:40','2011-09-16 14:27:40','Test.',0,'1','Django test framework','',0,0),(206,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-16 16:28:35','2011-09-16 14:28:35','Test.',0,'1','Django test framework','',0,0),(207,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-16 16:29:33','2011-09-16 14:29:33','Test.',0,'1','Django test framework','',0,0),(208,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-16 16:30:52','2011-09-16 14:30:52','Test.',0,'1','Django test framework','',0,0),(209,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-19 11:06:52','2011-09-19 09:06:52','Test.',0,'1','Django test framework','',0,0),(210,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-19 11:15:14','2011-09-19 09:15:14','Test.',0,'1','Django test framework','',0,0),(211,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-19 11:16:15','2011-09-19 09:16:15','Test.',0,'1','Django test framework','',0,0),(212,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-20 11:21:54','2011-09-20 09:21:54','Test.',0,'1','Django test framework','',0,0),(214,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-20 11:33:42','2011-09-20 09:33:42','Test.',0,'1','Django test framework','',0,0),(215,5,'ludo','ludo@qix.it','','127.0.0.1','2011-09-20 11:34:48','2011-09-20 09:34:48','Test.',0,'1','Django test framework','',0,0);
/*!40000 ALTER TABLE `wp_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_links`
--

DROP TABLE IF EXISTS `wp_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_links`
--

LOCK TABLES `wp_links` WRITE;
/*!40000 ALTER TABLE `wp_links` DISABLE KEYS */;
INSERT INTO `wp_links` VALUES (1,'http://codex.wordpress.org/','Documentation','','','aaa bbb','Y',1,0,'0000-00-00 00:00:00','','',''),(2,'http://wordpress.org/news/','WordPress Blog','','','','Y',1,0,'0000-00-00 00:00:00','','','http://wordpress.org/news/feed/'),(3,'http://wordpress.org/extend/ideas/','Suggest Ideas','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(4,'http://wordpress.org/support/','Support Forum','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(5,'http://wordpress.org/extend/plugins/','Plugins','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(6,'http://wordpress.org/extend/themes/','Themes','','','','Y',1,0,'0000-00-00 00:00:00','','',''),(7,'http://planet.wordpress.org/','WordPress Planet','','','','Y',1,0,'0000-00-00 00:00:00','','','');
/*!40000 ALTER TABLE `wp_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_options`
--

DROP TABLE IF EXISTS `wp_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL DEFAULT '0',
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=788 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_options`
--

LOCK TABLES `wp_options` WRITE;
/*!40000 ALTER TABLE `wp_options` DISABLE KEYS */;
INSERT INTO `wp_options` VALUES (1,0,'siteurl','http://mu.ludolo.it','yes'),(2,0,'blogname','WP Frontman','yes'),(3,0,'blogdescription','Just another WordPress site','yes'),(4,0,'users_can_register','0','yes'),(5,0,'admin_email','ludo@qix.it','yes'),(6,0,'start_of_week','1','yes'),(7,0,'use_balanceTags','0','yes'),(8,0,'use_smilies','1','yes'),(9,0,'require_name_email','1','yes'),(10,0,'comments_notify','1','yes'),(11,0,'posts_per_rss','10','yes'),(12,0,'rss_use_excerpt','0','yes'),(13,0,'mailserver_url','mail.example.com','yes'),(14,0,'mailserver_login','login@example.com','yes'),(15,0,'mailserver_pass','password','yes'),(16,0,'mailserver_port','110','yes'),(17,0,'default_category','1','yes'),(18,0,'default_comment_status','open','yes'),(19,0,'default_ping_status','open','yes'),(20,0,'default_pingback_flag','','yes'),(21,0,'default_post_edit_rows','20','yes'),(22,0,'posts_per_page','10','yes'),(23,0,'date_format','F j, Y','yes'),(24,0,'time_format','g:i a','yes'),(25,0,'links_updated_date_format','F j, Y g:i a','yes'),(26,0,'links_recently_updated_prepend','<em>','yes'),(27,0,'links_recently_updated_append','</em>','yes'),(28,0,'links_recently_updated_time','120','yes'),(29,0,'comment_moderation','','yes'),(30,0,'moderation_notify','1','yes'),(31,0,'permalink_structure','/%category%/%post_id%-%postname%/','yes'),(32,0,'gzipcompression','0','yes'),(33,0,'hack_file','0','yes'),(34,0,'blog_charset','UTF-8','yes'),(35,0,'moderation_keys','','no'),(36,0,'active_plugins','a:1:{i:0;s:18:\"wp-unit/WPUnit.php\";}','yes'),(37,0,'home','http://mu.ludolo.it','yes'),(38,0,'category_base','','yes'),(39,0,'ping_sites','http://rpc.pingomatic.com/','yes'),(40,0,'advanced_edit','0','yes'),(41,0,'comment_max_links','2','yes'),(42,0,'gmt_offset','0','yes'),(43,0,'default_email_category','1','yes'),(44,0,'recently_edited','','no'),(45,0,'template','twentyeleven','yes'),(46,0,'stylesheet','twentyeleven','yes'),(47,0,'comment_whitelist','1','yes'),(48,0,'blacklist_keys','','no'),(49,0,'comment_registration','1','yes'),(50,0,'rss_language','en','yes'),(51,0,'html_type','text/html','yes'),(52,0,'use_trackback','0','yes'),(53,0,'default_role','subscriber','yes'),(54,0,'db_version','19470','yes'),(55,0,'uploads_use_yearmonth_folders','1','yes'),(56,0,'upload_path','wp-content/uploads','yes'),(57,0,'blog_public','0','yes'),(58,0,'default_link_category','2','yes'),(59,0,'show_on_front','posts','yes'),(60,0,'tag_base','','yes'),(61,0,'show_avatars','1','yes'),(62,0,'avatar_rating','G','yes'),(63,0,'upload_url_path','','yes'),(64,0,'thumbnail_size_w','150','yes'),(65,0,'thumbnail_size_h','150','yes'),(66,0,'thumbnail_crop','1','yes'),(67,0,'medium_size_w','300','yes'),(68,0,'medium_size_h','300','yes'),(69,0,'avatar_default','mystery','yes'),(70,0,'enable_app','0','yes'),(71,0,'enable_xmlrpc','0','yes'),(72,0,'large_size_w','1024','yes'),(73,0,'large_size_h','1024','yes'),(74,0,'image_default_link_type','file','yes'),(75,0,'image_default_size','','yes'),(76,0,'image_default_align','','yes'),(77,0,'close_comments_for_old_posts','','yes'),(78,0,'close_comments_days_old','14','yes'),(79,0,'thread_comments','1','yes'),(80,0,'thread_comments_depth','5','yes'),(81,0,'page_comments','','yes'),(82,0,'comments_per_page','50','yes'),(83,0,'default_comments_page','newest','yes'),(84,0,'comment_order','asc','yes'),(85,0,'sticky_posts','a:0:{}','yes'),(86,0,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(87,0,'widget_text','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(88,0,'widget_rss','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(89,0,'timezone_string','','yes'),(90,0,'embed_autourls','1','yes'),(91,0,'embed_size_w','','yes'),(92,0,'embed_size_h','600','yes'),(93,0,'page_for_posts','0','yes'),(94,0,'page_on_front','0','yes'),(95,0,'default_post_format','0','yes'),(96,0,'wp_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes'),(97,0,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(98,0,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(99,0,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(100,0,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(101,0,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(102,0,'sidebars_widgets','a:8:{s:19:\"wp_inactive_widgets\";a:0:{}s:19:\"primary-widget-area\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:21:\"secondary-widget-area\";a:0:{}s:24:\"first-footer-widget-area\";a:0:{}s:25:\"second-footer-widget-area\";a:0:{}s:24:\"third-footer-widget-area\";a:0:{}s:25:\"fourth-footer-widget-area\";a:0:{}s:13:\"array_version\";i:3;}','yes'),(103,0,'cron','a:4:{i:1332196317;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1332196583;a:1:{s:21:\"update_network_counts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1332239524;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}','yes'),(105,0,'_site_transient_update_core','O:8:\"stdClass\":3:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":7:{s:8:\"response\";s:6:\"latest\";s:3:\"url\";s:30:\"http://wordpress.org/download/\";s:7:\"package\";s:38:\"http://wordpress.org/wordpress-3.1.zip\";s:7:\"current\";s:3:\"3.1\";s:6:\"locale\";s:5:\"en_US\";s:11:\"php_version\";s:3:\"4.3\";s:13:\"mysql_version\";s:5:\"4.1.2\";}}s:12:\"last_checked\";i:1301394721;s:15:\"version_checked\";s:3:\"3.1\";}','yes'),(106,0,'_site_transient_update_plugins','O:8:\"stdClass\":3:{s:12:\"last_checked\";i:1301394722;s:7:\"checked\";a:11:{s:19:\"akismet/akismet.php\";s:5:\"2.5.3\";s:22:\"better_thumbnailer.php\";s:3:\"0.1\";s:14:\"lp_caption.php\";s:3:\"0.1\";s:9:\"hello.php\";s:3:\"1.6\";s:25:\"linkwithin/linkwithin.php\";s:4:\"0.85\";s:17:\"lp_feedburner.php\";s:3:\"0.1\";s:19:\"mycategoryorder.php\";s:5:\"3.0.1\";s:27:\"simple-tags/simple-tags.php\";s:3:\"1.8\";s:41:\"wordpress-importer/wordpress-importer.php\";s:3:\"0.2\";s:43:\"wp-cms-post-control/wp-cms-post-control.php\";s:3:\"2.4\";s:27:\"wp-super-cache/wp-cache.php\";s:7:\"0.9.9.8\";}s:8:\"response\";a:3:{s:27:\"simple-tags/simple-tags.php\";O:8:\"stdClass\":5:{s:2:\"id\";s:4:\"1112\";s:4:\"slug\";s:11:\"simple-tags\";s:11:\"new_version\";s:9:\"2.0-beta9\";s:3:\"url\";s:48:\"http://wordpress.org/extend/plugins/simple-tags/\";s:7:\"package\";s:63:\"http://downloads.wordpress.org/plugin/simple-tags.2.0-beta9.zip\";}s:41:\"wordpress-importer/wordpress-importer.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"14975\";s:4:\"slug\";s:18:\"wordpress-importer\";s:11:\"new_version\";s:3:\"0.3\";s:14:\"upgrade_notice\";s:130:\"Upgrade for a more robust and reliable experience when importing WordPress export files, and for compatibility with WordPress 3.1.\";s:3:\"url\";s:55:\"http://wordpress.org/extend/plugins/wordpress-importer/\";s:7:\"package\";s:64:\"http://downloads.wordpress.org/plugin/wordpress-importer.0.3.zip\";}s:27:\"wp-super-cache/wp-cache.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:4:\"1221\";s:4:\"slug\";s:14:\"wp-super-cache\";s:11:\"new_version\";s:7:\"0.9.9.9\";s:14:\"upgrade_notice\";s:87:\"Serve repeated static files from the same CDN hostname, translations, lots of bug fixes\";s:3:\"url\";s:51:\"http://wordpress.org/extend/plugins/wp-super-cache/\";s:7:\"package\";s:64:\"http://downloads.wordpress.org/plugin/wp-super-cache.0.9.9.9.zip\";}}}','yes'),(107,0,'widget_pages','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(108,0,'widget_calendar','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(109,0,'widget_links','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(110,0,'widget_tag_cloud','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(111,0,'widget_nav_menu','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(112,0,'_site_transient_timeout_theme_roots','1301401922','yes'),(113,0,'_site_transient_theme_roots','a:4:{s:10:\"darkmatter\";s:7:\"/themes\";s:16:\"minimalism 1.0.2\";s:7:\"/themes\";s:12:\"sharp_orange\";s:7:\"/themes\";s:9:\"twentyten\";s:7:\"/themes\";}','yes'),(114,0,'_site_transient_update_themes','O:8:\"stdClass\":1:{s:12:\"last_checked\";i:1301394723;}','yes'),(115,0,'dashboard_widget_options','a:4:{s:25:\"dashboard_recent_comments\";a:1:{s:5:\"items\";i:5;}s:24:\"dashboard_incoming_links\";a:5:{s:4:\"home\";s:19:\"http://mu.ludolo.it\";s:4:\"link\";s:95:\"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://mu.ludolo.it/\";s:3:\"url\";s:125:\"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://localhost/\";s:5:\"items\";i:10;s:9:\"show_date\";b:0;}s:17:\"dashboard_primary\";a:7:{s:4:\"link\";s:26:\"http://wordpress.org/news/\";s:3:\"url\";s:31:\"http://wordpress.org/news/feed/\";s:5:\"title\";s:14:\"WordPress Blog\";s:5:\"items\";i:2;s:12:\"show_summary\";i:1;s:11:\"show_author\";i:0;s:9:\"show_date\";i:1;}s:19:\"dashboard_secondary\";a:7:{s:4:\"link\";s:28:\"http://planet.wordpress.org/\";s:3:\"url\";s:33:\"http://planet.wordpress.org/feed/\";s:5:\"title\";s:20:\"Other WordPress News\";s:5:\"items\";i:5;s:12:\"show_summary\";i:0;s:11:\"show_author\";i:0;s:9:\"show_date\";i:0;}}','yes'),(144,0,'fileupload_url','http://mu.ludolo.it/wp-content/uploads','yes'),(147,0,'recently_activated','a:0:{}','yes'),(149,0,'db_upgraded','','yes'),(185,0,'post_count','6','yes'),(186,0,'_wpf_featured_images','a:2:{s:7:\"enabled\";b:1;s:12:\"image_height\";s:3:\"300\";}','yes'),(217,0,'_wpf_preformatter','a:6:{s:7:\"enabled\";b:1;s:6:\"max_id\";s:2:\"28\";s:10:\"batch_size\";i:1000;s:10:\"batch_done\";b:1;s:13:\"batch_running\";b:0;s:13:\"relative_urls\";b:0;}','yes'),(240,0,'allowedthemes','a:1:{s:12:\"twentyeleven\";b:1;}','yes'),(241,0,'current_theme','Twenty Eleven','yes'),(242,0,'theme_mods_twentyeleven','a:1:{i:0;b:0;}','yes'),(244,0,'widget_widget_twentyeleven_ephemera','a:2:{i:2;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(670,0,'test_children','a:1:{i:31;a:1:{i:0;i:33;}}','yes'),(758,0,'_transient_timeout_plugin_slugs','1331822034','no'),(759,0,'_transient_plugin_slugs','a:4:{i:0;s:19:\"akismet/akismet.php\";i:1;s:9:\"hello.php\";i:2;s:18:\"wp-unit/WPUnit.php\";i:3;s:27:\"wp_frontman/wp_frontman.php\";}','no'),(765,0,'rewrite_rules','a:74:{s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:16:\".*wp-signup.php$\";s:21:\"index.php?signup=true\";s:18:\".*wp-activate.php$\";s:23:\"index.php?activate=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:29:\"comments/page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:74:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:69:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:62:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:44:\"date/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:61:\"date/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:56:\"date/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:49:\"date/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:31:\"date/([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:48:\"date/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:43:\"date/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:36:\"date/([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:18:\"date/([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:38:\".+?/[0-9]+-[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:48:\".+?/[0-9]+-[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:68:\".+?/[0-9]+-[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\".+?/[0-9]+-[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:63:\".+?/[0-9]+-[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"(.+?)/([0-9]+)-([^/]+)/trackback/?$\";s:71:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&tb=1\";s:55:\"(.+?)/([0-9]+)-([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:83:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&feed=$matches[4]\";s:50:\"(.+?)/([0-9]+)-([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:83:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&feed=$matches[4]\";s:43:\"(.+?)/([0-9]+)-([^/]+)/page/?([0-9]{1,})/?$\";s:84:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&paged=$matches[4]\";s:50:\"(.+?)/([0-9]+)-([^/]+)/comment-page-([0-9]{1,})/?$\";s:84:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&cpage=$matches[4]\";s:35:\"(.+?)/([0-9]+)-([^/]+)(/[0-9]+)?/?$\";s:83:\"index.php?category_name=$matches[1]&p=$matches[2]&name=$matches[3]&page=$matches[4]\";s:27:\".+?/[0-9]+-[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".+?/[0-9]+-[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".+?/[0-9]+-[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".+?/[0-9]+-[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".+?/[0-9]+-[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:33:\"(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:26:\"(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:33:\"(.+?)/comment-page-([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&cpage=$matches[2]\";s:8:\"(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";}','yes'),(772,0,'_transient_timeout_dash_de3249c4736ad3bd2cd29147c4a0d43e','1331778794','no'),(773,0,'_transient_dash_de3249c4736ad3bd2cd29147c4a0d43e','','no'),(783,0,'wp_frontman','a:15:{s:17:\"custom_taxonomies\";a:1:{s:6:\"things\";a:13:{s:8:\"_builtin\";b:0;s:12:\"hierarchical\";b:1;s:5:\"label\";s:6:\"Things\";s:4:\"name\";s:6:\"things\";s:11:\"object_type\";a:1:{i:11;s:4:\"post\";}s:6:\"public\";b:1;s:9:\"query_var\";b:1;s:7:\"rewrite\";a:3:{s:4:\"slug\";s:6:\"things\";s:10:\"with_front\";b:1;s:12:\"hierarchical\";b:1;}s:21:\"update_count_callback\";s:23:\"_update_post_term_count\";s:5:\"count\";b:1;s:12:\"rewrite_slug\";s:6:\"things\";s:18:\"rewrite_with_front\";b:1;s:20:\"rewrite_hierarchical\";b:1;}}s:17:\"custom_post_types\";a:0:{}s:14:\"favicon_source\";s:5:\"httpd\";s:12:\"favicon_file\";s:69:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/1/files/favicon.ico\";s:13:\"robots_source\";s:5:\"httpd\";s:11:\"robots_file\";s:68:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/1/files/robots.txt\";s:7:\"rewrite\";a:8:{s:19:\"permalink_structure\";s:33:\"/%category%/%post_id%-%postname%/\";s:11:\"author_base\";s:6:\"author\";s:11:\"search_base\";s:6:\"search\";s:13:\"comments_base\";s:8:\"comments\";s:15:\"pagination_base\";s:4:\"page\";s:9:\"feed_base\";s:4:\"feed\";s:13:\"category_base\";s:0:\"\";s:8:\"tag_base\";s:0:\"\";}s:5:\"cache\";a:3:{s:5:\"label\";s:5:\"Cache\";s:7:\"enabled\";b:1;s:8:\"endpoint\";s:30:\"http://mu.ludolo.it/wpf_cache/\";}s:12:\"preformatter\";a:7:{s:5:\"label\";s:13:\"Preformatting\";s:7:\"enabled\";b:0;s:6:\"max_id\";i:0;s:10:\"batch_size\";i:500;s:10:\"batch_done\";b:0;s:13:\"batch_running\";b:0;s:13:\"relative_urls\";b:1;}s:5:\"feeds\";a:6:{s:5:\"label\";s:16:\"Feed Redirection\";s:7:\"enabled\";b:0;s:6:\"target\";N;s:5:\"paths\";N;s:15:\"comments_target\";N;s:14:\"comments_paths\";s:0:\"\";}s:6:\"images\";a:3:{s:5:\"label\";s:6:\"Images\";s:7:\"enabled\";b:0;s:5:\"sizes\";a:0:{}}s:9:\"analytics\";a:6:{s:5:\"label\";s:16:\"Google Analytics\";s:5:\"token\";N;s:13:\"session_token\";N;s:12:\"account_name\";N;s:10:\"account_id\";N;s:6:\"filter\";N;}s:11:\"_db_version\";i:5;s:7:\"_t_init\";i:1331737042;s:7:\"_t_save\";i:1332156090;}','yes'),(785,0,'_transient_timeout_dirsize_cache','1332149680','no'),(786,0,'_transient_dirsize_cache','a:1:{s:58:\"/var/virtual/wp/wordpress-mu/wp-content/blogs.dir/1/files/\";a:1:{s:4:\"size\";b:0;}}','no');
/*!40000 ALTER TABLE `wp_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_postmeta`
--

DROP TABLE IF EXISTS `wp_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_postmeta`
--

LOCK TABLES `wp_postmeta` WRITE;
/*!40000 ALTER TABLE `wp_postmeta` DISABLE KEYS */;
INSERT INTO `wp_postmeta` VALUES (1,2,'_wp_page_template','default'),(5,5,'_edit_last','1'),(6,5,'_edit_lock','1311073677:1'),(8,5,'_wp_old_slug',''),(17,2,'_edit_lock','1300097690'),(18,13,'_edit_last','1'),(19,13,'_edit_lock','1300113110'),(20,13,'_wp_page_template','default'),(21,15,'_edit_last','1'),(22,15,'_edit_lock','1300118202'),(23,15,'_wp_page_template','default'),(24,19,'_edit_last','1'),(25,19,'_edit_lock','1316423535:1'),(27,19,'_wp_old_slug',''),(28,21,'_edit_last','1'),(29,21,'_edit_lock','1310997324:1'),(31,21,'_wp_old_slug',''),(32,23,'_edit_last','1'),(33,23,'_edit_lock','1300184179'),(35,23,'_wp_old_slug',''),(36,25,'_edit_last','1'),(37,25,'_edit_lock','1300782266'),(39,25,'_wp_old_slug',''),(41,28,'_edit_last','1'),(42,28,'_edit_lock','1316423508:1'),(44,28,'_wp_old_slug',''),(45,32,'_wp_attached_file','2011/03/dp2-1.jpg'),(46,32,'_wp_attachment_metadata','a:6:{s:5:\"width\";s:3:\"800\";s:6:\"height\";s:3:\"533\";s:14:\"hwstring_small\";s:23:\"height=\'85\' width=\'128\'\";s:4:\"file\";s:17:\"2011/03/dp2-1.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:3:{s:4:\"file\";s:17:\"dp2-1-150x150.jpg\";s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";}s:6:\"medium\";a:3:{s:4:\"file\";s:17:\"dp2-1-300x199.jpg\";s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"199\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:4:\"NX10\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1307789380\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";}}'),(48,34,'_wp_attached_file','2011/03/dp2-2.jpg'),(49,34,'_wp_attachment_metadata','a:6:{s:5:\"width\";s:3:\"800\";s:6:\"height\";s:3:\"532\";s:14:\"hwstring_small\";s:23:\"height=\'85\' width=\'128\'\";s:4:\"file\";s:17:\"2011/03/dp2-2.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:3:{s:4:\"file\";s:17:\"dp2-2-150x150.jpg\";s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";}s:6:\"medium\";a:3:{s:4:\"file\";s:17:\"dp2-2-300x199.jpg\";s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"199\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:4:\"NX10\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1307789462\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:17:\"0.016666666666667\";s:5:\"title\";s:0:\"\";}}'),(50,5,'_thumbnail_id','34'),(52,37,'_wp_attached_file','2011/03/dp2-3.jpg'),(53,37,'_wp_attachment_metadata','a:6:{s:5:\"width\";s:3:\"800\";s:6:\"height\";s:3:\"533\";s:14:\"hwstring_small\";s:23:\"height=\'85\' width=\'128\'\";s:4:\"file\";s:17:\"2011/03/dp2-3.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:3:{s:4:\"file\";s:17:\"dp2-3-150x150.jpg\";s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";}s:6:\"medium\";a:3:{s:4:\"file\";s:17:\"dp2-3-300x199.jpg\";s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"199\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:4:\"NX10\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1307789413\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:3:\"200\";s:13:\"shutter_speed\";s:17:\"0.022222222222222\";s:5:\"title\";s:0:\"\";}}'),(54,19,'_thumbnail_id','37'),(55,21,'_thumbnail_id','32'),(56,41,'_wp_attached_file','2011/08/simplyrobin_olympus_45mm.jpg'),(57,41,'_wp_attachment_metadata','a:6:{s:5:\"width\";s:3:\"925\";s:6:\"height\";s:3:\"694\";s:14:\"hwstring_small\";s:23:\"height=\'96\' width=\'128\'\";s:4:\"file\";s:36:\"2011/08/simplyrobin_olympus_45mm.jpg\";s:5:\"sizes\";a:5:{s:9:\"thumbnail\";a:3:{s:4:\"file\";s:36:\"simplyrobin_olympus_45mm-150x150.jpg\";s:5:\"width\";s:3:\"150\";s:6:\"height\";s:3:\"150\";}s:6:\"medium\";a:3:{s:4:\"file\";s:36:\"simplyrobin_olympus_45mm-300x225.jpg\";s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"225\";}s:14:\"post-thumbnail\";a:3:{s:4:\"file\";s:36:\"simplyrobin_olympus_45mm-925x288.jpg\";s:5:\"width\";s:3:\"925\";s:6:\"height\";s:3:\"288\";}s:13:\"large-feature\";a:3:{s:4:\"file\";s:36:\"simplyrobin_olympus_45mm-925x288.jpg\";s:5:\"width\";s:3:\"925\";s:6:\"height\";s:3:\"288\";}s:13:\"small-feature\";a:3:{s:4:\"file\";s:36:\"simplyrobin_olympus_45mm-399x300.jpg\";s:5:\"width\";s:3:\"399\";s:6:\"height\";s:3:\"300\";}}s:10:\"image_meta\";a:10:{s:8:\"aperture\";s:3:\"1.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:4:\"E-P3\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1313783602\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:2:\"45\";s:3:\"iso\";s:4:\"1250\";s:13:\"shutter_speed\";s:5:\"0.004\";s:5:\"title\";s:22:\"OLYMPUS DIGITAL CAMERA\";}}'),(58,40,'_edit_last','1'),(59,40,'_edit_lock','1314029065:1'),(60,41,'_wp_attachment_image_alt','Image alt');
/*!40000 ALTER TABLE `wp_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_posts`
--

DROP TABLE IF EXISTS `wp_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` text NOT NULL,
  `post_parent` bigint(20) unsigned DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_posts`
--

LOCK TABLES `wp_posts` WRITE;
/*!40000 ALTER TABLE `wp_posts` DISABLE KEYS */;
INSERT INTO `wp_posts` VALUES (2,1,'2011-03-10 09:14:03','2011-03-10 09:14:03','This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.','About','','publish','open','open','','about','','','2011-03-10 09:14:03','2011-03-10 09:14:03','\0<p>This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.</p>\n\01299744843',NULL,'http://localhost/?page_id=2',0,'page','',0),(5,1,'2011-03-10 09:18:35','2011-03-10 09:18:35','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<!--more-->\r\n\r\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','publish','open','open','','post-in-first-category','','','2011-07-17 11:31:03','2011-07-17 11:31:03','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.</p>\n\0<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<span id=\"more-5\"></span></p>\n<p>Phasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.</p>\n\01310895063',0,'http://localhost/?p=5',0,'post','',205),(6,1,'2011-03-10 09:17:51','2011-03-10 09:17:51','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.\n\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','inherit','open','open','','5-revision','','','2011-03-10 09:17:51','2011-03-10 09:17:51','',5,'http://localhost/?p=6',0,'revision','',0),(9,1,'2011-07-19 11:09:00','2011-07-19 11:09:00','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<!--more-->\n\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','inherit','open','open','','5-autosave','','','2011-07-19 11:09:00','2011-07-19 11:09:00','',5,'http://localhost/?p=9',0,'revision','',0),(10,1,'2011-03-10 09:18:35','2011-03-10 09:18:35','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<!--more-->\r\n\r\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','inherit','open','open','','5-revision-2','','','2011-03-10 09:18:35','2011-03-10 09:18:35','',5,'http://localhost/?p=10',0,'revision','',0),(11,1,'2011-03-10 09:34:51','2011-03-10 09:34:51','<a href=\"http://localhost/wp-content/uploads/2011/03/thumbnail_imgp3440.jpg\"><img src=\"http://localhost/wp-content/uploads/2011/03/thumbnail_imgp3440-200x300.jpg\" alt=\"\" title=\"thumbnail_imgp3440\" width=\"200\" height=\"300\" class=\"alignnone size-medium wp-image-7\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<!--more-->\n\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','inherit','open','open','','5-revision-3','','','2011-03-10 09:34:51','2011-03-10 09:34:51','',5,'http://localhost/?p=11',0,'revision','',0),(12,1,'2011-03-10 09:34:54','2011-03-10 09:34:54','<a href=\"http://localhost/wp-content/uploads/2011/03/thumbnail_imgp3440.jpg\"><img src=\"http://localhost/wp-content/uploads/2011/03/thumbnail_imgp3440-200x300.jpg\" alt=\"\" title=\"thumbnail_imgp3440\" width=\"200\" height=\"300\" class=\"alignnone size-medium wp-image-7\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<!--more-->\r\n\r\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','inherit','open','open','','5-revision-4','','','2011-03-10 09:34:54','2011-03-10 09:34:54','',5,'http://localhost/?p=12',0,'revision','',0),(13,1,'2011-03-14 15:31:50','2011-03-14 14:31:50','Test.','About child','','publish','open','open','','about-child','','','2011-03-14 15:31:50','2011-03-14 14:31:50','\0<p>Test.</p>\n\01300109510',2,'http://localhost/',0,'page','',0),(14,1,'2011-03-14 15:31:34','2011-03-14 14:31:34','','Auto Draft','','inherit','open','open','','13-revision','','','2011-03-14 15:31:34','2011-03-14 14:31:34','',13,'http://localhost/2011/03/14/13-revision/',0,'revision','',0),(15,1,'2011-03-14 15:36:00','2011-03-14 14:36:00','Another page.','Another page','','publish','open','open','','another-page','','','2011-03-14 15:36:00','2011-03-14 14:36:00','\0<p>Another page.</p>\n\01300109760',NULL,'http://localhost/',0,'page','',0),(16,1,'2011-03-14 15:31:53','2011-03-14 14:31:53','','Auto Draft','','inherit','open','open','','15-revision','','','2011-03-14 15:31:53','2011-03-14 14:31:53','',15,'http://localhost/2011/03/14/15-revision/',0,'revision','',0),(17,1,'2011-03-14 15:31:53','2011-03-14 14:31:53','','Auto Draft','','inherit','open','open','','15-revision-2','','','2011-03-14 15:31:53','2011-03-14 14:31:53','',15,'http://localhost/2011/03/14/15-revision-2/',0,'revision','',0),(18,1,'2011-03-14 15:31:53','2011-03-14 14:31:53','','Auto Draft','','inherit','open','open','','15-revision-3','','','2011-03-14 15:31:53','2011-03-14 14:31:53','',15,'http://localhost/2011/03/14/15-revision-3/',0,'revision','',0),(19,1,'2011-03-15 11:10:23','2011-03-15 11:10:23','Test','Post in first category first subchild','','publish','open','open','','post-in-first-category-first-subchild','','','2011-09-19 09:12:15','2011-09-19 09:12:15','\0<p>Test</p>\n\01316416335',0,'http://localhost/?p=19',0,'post','',0),(20,1,'2011-03-15 11:10:05','2011-03-15 10:10:05','','Post in ','','inherit','open','open','','19-revision','','','2011-03-15 11:10:05','2011-03-15 10:10:05','',19,'http://localhost/2011/03/15/19-revision/',0,'revision','',0),(21,1,'2011-03-15 11:15:29','2011-03-15 10:15:29','Another post.','Post in third category','','publish','open','open','','post-in-third-category','','','2011-03-15 11:15:29','2011-03-15 10:15:29','\0<p>Another post.</p>\n\01300180529',NULL,'http://localhost/?p=21',0,'post','',0),(22,1,'2011-03-15 11:15:14','2011-03-15 10:15:14','','Post in third category','','inherit','open','open','','21-revision','','','2011-03-15 11:15:14','2011-03-15 10:15:14','',21,'http://localhost/2011/03/15/21-revision/',0,'revision','',0),(23,1,'2011-03-15 11:15:48','2011-03-15 10:15:48','Yet another.','Post in third category / 2','','publish','open','open','','post-in-third-category-2','','','2011-03-15 11:16:19','2011-03-15 10:16:19','\0<p>Yet another.</p>\n\01300180579',NULL,'http://localhost/?p=23',0,'post','',0),(24,1,'2011-03-15 11:15:42','2011-03-15 10:15:42','','Post in third Category / 2','','inherit','open','open','','23-revision','','','2011-03-15 11:15:42','2011-03-15 10:15:42','',23,'http://localhost/2011/03/15/23-revision/',0,'revision','',0),(25,1,'2011-03-15 11:16:08','2011-03-15 10:16:08','Here it is.','Post in second category first child','','publish','closed','closed','','post-in-second-category-first-child','','','2011-03-22 09:24:26','2011-03-22 08:24:26','\0<p>Here it is.</p>\n\01300778666',NULL,'http://localhost/?p=25',0,'post','',0),(26,1,'2011-03-15 11:16:03','2011-03-15 10:16:03','','Post in second category first child','','inherit','open','open','','25-revision','','','2011-03-15 11:16:03','2011-03-15 10:16:03','',25,'http://localhost/2011/03/15/25-revision/',0,'revision','',0),(27,1,'2011-03-15 11:15:48','2011-03-15 10:15:48','Yet another.','Post in third Category / 2','','inherit','open','open','','23-revision-2','','','2011-03-15 11:15:48','2011-03-15 10:15:48','',23,'http://localhost/2011/03/15/23-revision-2/',0,'revision','',0),(28,1,'2011-03-15 11:16:42','2011-03-15 10:16:42','Once more.','Post in first category / 2','','publish','open','open','','post-in-first-category-2','','','2011-09-19 09:11:26','2011-09-19 09:11:26','\0<p>Once more.</p>\n\01316416286',0,'http://localhost/?p=28',0,'post','',0),(29,1,'2011-03-15 11:16:32','2011-03-15 10:16:32','','Post in first category / 2','','inherit','open','open','','28-revision','','','2011-03-15 11:16:32','2011-03-15 10:16:32','',28,'http://localhost/2011/03/15/28-revision/',0,'revision','',0),(30,1,'2011-03-15 11:16:08','2011-03-15 10:16:08','Here it is.','Post in second category first child','','inherit','open','open','','25-revision-2','','','2011-03-15 11:16:08','2011-03-15 10:16:08','',25,'http://localhost/2011/03/15/25-revision-2/',0,'revision','',0),(31,1,'2011-03-15 11:16:42','2011-03-15 10:16:42','Once more.','Post in first category / 2','','inherit','open','open','','28-revision-2','','','2011-03-15 11:16:42','2011-03-15 10:16:42','',28,'http://localhost/2011/03/15/28-revision-2/',0,'revision','',0),(32,1,'2011-07-17 11:28:14','2011-07-17 11:28:14','','dp2-1','','inherit','open','open','','dp2-1','','','2011-07-17 11:28:14','2011-07-17 11:28:14','',5,'http://ludolo.it/wp-content/uploads/2011/03/dp2-1.jpg',0,'attachment','image/jpeg',0),(33,1,'2011-03-10 09:35:15','2011-03-10 09:35:15','<a href=\"http://localhost/wp-content/uploads/2011/03/thumbnail_imgp3440.jpg\"><img src=\"http://localhost/wp-content/uploads/2011/03/thumbnail_imgp3440-200x300.jpg\" alt=\"\" title=\"thumbnail_imgp3440\" width=\"200\" height=\"300\" class=\"alignnone size-medium wp-image-7\" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<!--more-->\r\n\r\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','inherit','open','open','','5-revision-5','','','2011-03-10 09:35:15','2011-03-10 09:35:15','',5,'http://ludolo.it/uncategorized/33-5-revision-5/',0,'revision','',0),(34,1,'2011-07-17 11:30:48','2011-07-17 11:30:48','','dp2-2','','inherit','open','open','','dp2-2','','','2011-07-17 11:30:48','2011-07-17 11:30:48','',5,'http://ludolo.it/wp-content/uploads/2011/03/dp2-2.jpg',0,'attachment','image/jpeg',0),(35,1,'2011-07-17 11:28:37','2011-07-17 11:28:37','Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac lacus enim, non imperdiet nunc. Ut et velit eu nisi pretium egestas. Sed ac pulvinar lectus. Proin egestas metus lectus. Sed consequat, ipsum quis pellentesque vulputate, risus velit vulputate odio, eu blandit augue eros in erat. Morbi gravida pretium vulputate. Nullam sodales auctor eros, vitae luctus eros pharetra sit amet. Fusce vulputate, magna id aliquam interdum, metus eros vulputate dui, imperdiet semper turpis tellus ut felis. Proin interdum est id dolor porttitor ac consectetur diam malesuada. Nullam nec eros neque, quis fringilla leo. Praesent nec dui vulputate arcu dignissim hendrerit. Fusce interdum diam nec neque porta mattis. Fusce eu arcu erat, ut commodo metus. In ac arcu leo, eget posuere nulla. Proin mattis sodales lacus, at tristique velit feugiat vitae. Aenean viverra euismod mauris id tempor. Suspendisse tincidunt vestibulum massa, dignissim congue mauris tempus et. Nam eget lorem nisi.<!--more-->\r\n\r\nPhasellus augue sem, ultricies ut luctus in, adipiscing eu ligula. Duis adipiscing neque ut ligula porta porttitor. Nunc bibendum, ipsum non porta laoreet, mauris ante varius tellus, vitae dictum odio eros eget nunc. In gravida nulla sit amet leo iaculis condimentum in vitae orci. Suspendisse et metus purus. Curabitur sagittis tristique eros, nec semper massa suscipit aliquet. Sed sit amet metus augue. Donec cursus vehicula nisl, et sagittis mi interdum vitae. Cras nisi nisi, rhoncus eu consectetur sit amet, viverra et erat. Nullam et nisl quis lacus bibendum rutrum. Donec eleifend, massa et varius volutpat, magna mi posuere orci, lobortis dignissim massa nulla vitae enim. Nulla neque metus, blandit a blandit sed, interdum eget turpis. Etiam non leo metus, vel luctus ante. Aliquam venenatis pretium dolor eu convallis. Nulla volutpat ultrices lobortis. In pretium leo eu lectus tristique quis dapibus eros vulputate.','Post in first category','','inherit','open','open','','5-revision-6','','','2011-07-17 11:28:37','2011-07-17 11:28:37','',5,'http://ludolo.it/uncategorized/35-5-revision-6/',0,'revision','',0),(37,1,'2011-07-17 11:31:46','2011-07-17 11:31:46','','dp2-3','','inherit','open','open','','dp2-3','','','2011-07-17 11:31:46','2011-07-17 11:31:46','',19,'http://ludolo.it/wp-content/uploads/2011/03/dp2-3.jpg',0,'attachment','image/jpeg',0),(39,1,'2011-07-18 13:56:28','2011-07-18 13:56:28','Another post.','Post in third category','','inherit','open','open','','21-autosave','','','2011-07-18 13:56:28','2011-07-18 13:56:28','',21,'http://ludolo.it/uncategorized/39-21-autosave/',0,'revision','',0),(40,1,'2011-08-22 16:04:25','0000-00-00 00:00:00','<img class=\"size-full wp-image-41\" title=\"Image title\" src=\"http://ludolo.it/wp-content/uploads/2011/08/simplyrobin_olympus_45mm.jpg\" alt=\"Image alt\" width=\"925\" height=\"694\" />\n<span class=\"image_attribution\">Image <em>caption</em></span>\n<p class=\"image_container\"><img class=\"frame_left\" title=\"Image title\" src=\"http://ludolo.it/wp-content/uploads/2011/08/simplyrobin_olympus_45mm-300x225.jpg\" alt=\"Image alt\" width=\"300\" height=\"225\" />\n<span class=\"image_attribution\">Image <em>caption</em></span></p>','','','draft','open','open','','','','','2011-08-22 16:04:25','2011-08-22 16:04:25','',0,'http://ludolo.it/?p=40',0,'post','',0),(41,1,'2011-08-22 15:29:14','2011-08-22 15:29:14','','Image title','Image <em>caption</em>','inherit','open','open','','olympus-digital-camera','','','2011-08-22 15:29:14','2011-08-22 15:29:14','',40,'http://ludolo.it/wp-content/uploads/2011/08/simplyrobin_olympus_45mm.jpg',0,'attachment','image/jpeg',0),(42,1,'2011-08-23 14:50:18','0000-00-00 00:00:00','','Bozza automatica','','auto-draft','open','open','','','','','2011-08-23 14:50:18','0000-00-00 00:00:00','',0,'http://ludolo.it/?p=42',0,'post','',0),(43,1,'2011-03-22 09:35:09','2011-03-22 08:35:09','Once more.','Post in first category / 2','','inherit','open','open','','28-revision-3','','','2011-03-22 09:35:09','2011-03-22 08:35:09','',28,'http://ludolo.it/uncategorized/43-28-revision-3/',0,'revision','',0),(44,1,'2011-03-15 11:10:23','2011-03-15 10:10:23','Test','Post in first category first subchild','','inherit','open','open','','19-revision-2','','','2011-03-15 11:10:23','2011-03-15 10:10:23','',19,'http://ludolo.it/uncategorized/44-19-revision-2/',0,'revision','',0);
/*!40000 ALTER TABLE `wp_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_registration_log`
--

DROP TABLE IF EXISTS `wp_registration_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL DEFAULT '',
  `IP` varchar(30) NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_registration_log`
--

LOCK TABLES `wp_registration_log` WRITE;
/*!40000 ALTER TABLE `wp_registration_log` DISABLE KEYS */;
INSERT INTO `wp_registration_log` VALUES (1,'ludo@qix.it','127.0.0.1',2,'2011-03-29 10:37:15'),(2,'ludo@qix.it','127.0.0.1',3,'2011-03-29 10:37:35');
/*!40000 ALTER TABLE `wp_registration_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_signups`
--

DROP TABLE IF EXISTS `wp_signups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_signups` (
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  `title` longtext NOT NULL,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) NOT NULL DEFAULT '',
  `meta` longtext,
  KEY `activation_key` (`activation_key`),
  KEY `domain` (`domain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_signups`
--

LOCK TABLES `wp_signups` WRITE;
/*!40000 ALTER TABLE `wp_signups` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_signups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_site`
--

DROP TABLE IF EXISTS `wp_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) NOT NULL DEFAULT '',
  `path` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`,`path`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_site`
--

LOCK TABLES `wp_site` WRITE;
/*!40000 ALTER TABLE `wp_site` DISABLE KEYS */;
INSERT INTO `wp_site` VALUES (1,'localhost','/');
/*!40000 ALTER TABLE `wp_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_sitemeta`
--

DROP TABLE IF EXISTS `wp_sitemeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_sitemeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_sitemeta`
--

LOCK TABLES `wp_sitemeta` WRITE;
/*!40000 ALTER TABLE `wp_sitemeta` DISABLE KEYS */;
INSERT INTO `wp_sitemeta` VALUES (1,1,'site_name','WP Frontman Sites'),(2,1,'admin_email','ludo@qix.it'),(3,1,'admin_user_id','1'),(4,1,'registration','user'),(5,1,'upload_filetypes','jpg jpeg png gif mp3 mov avi wmv midi mid pdf'),(6,1,'blog_upload_space','10'),(7,1,'fileupload_maxk','1500'),(8,1,'site_admins','a:1:{i:0;s:4:\"ludo\";}'),(9,1,'allowedthemes','a:1:{s:9:\"twentyten\";b:1;}'),(10,1,'illegal_names','a:9:{i:0;s:3:\"www\";i:1;s:3:\"web\";i:2;s:4:\"root\";i:3;s:5:\"admin\";i:4;s:4:\"main\";i:5;s:6:\"invite\";i:6;s:13:\"administrator\";i:7;s:5:\"files\";i:8;s:4:\"blog\";}'),(11,1,'wpmu_upgrade_site','19470'),(12,1,'welcome_email','Dear User,\r\n\r\nYour new SITE_NAME site has been successfully set up at:\r\nBLOG_URL\r\n\r\nYou can log in to the administrator account with the following information:\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLogin Here: BLOG_URLwp-login.php\r\n\r\nWe hope you enjoy your new site.\r\nThanks!\r\n\r\n--The Team @ SITE_NAME'),(13,1,'first_post','Welcome to <a href=\"SITE_URL\">SITE_NAME</a>. This is your first post. Edit or delete it, then start blogging!'),(14,1,'siteurl','http://mu.ludolo.it/'),(15,1,'add_new_users','1'),(16,1,'upload_space_check_disabled','0'),(17,1,'subdomain_install','0'),(18,1,'global_terms_enabled','0'),(19,1,'dm_hash','08a8dd7eddc3a319af6751a8f62560f9'),(21,1,'_site_transient_update_plugins','O:8:\"stdClass\":3:{s:12:\"last_checked\";i:1332146079;s:7:\"checked\";a:4:{s:19:\"akismet/akismet.php\";s:5:\"2.5.3\";s:9:\"hello.php\";s:3:\"1.6\";s:18:\"wp-unit/WPUnit.php\";s:3:\"1.0\";s:27:\"wp_frontman/wp_frontman.php\";s:3:\"0.1\";}s:8:\"response\";a:1:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":5:{s:2:\"id\";s:2:\"15\";s:4:\"slug\";s:7:\"akismet\";s:11:\"new_version\";s:5:\"2.5.4\";s:3:\"url\";s:44:\"http://wordpress.org/extend/plugins/akismet/\";s:7:\"package\";s:55:\"http://downloads.wordpress.org/plugin/akismet.2.5.4.zip\";}}}'),(24,1,'_site_transient_update_themes','O:8:\"stdClass\":3:{s:12:\"last_checked\";i:1332156068;s:7:\"checked\";a:2:{s:12:\"twentyeleven\";s:3:\"1.2\";s:9:\"twentyten\";s:3:\"1.2\";}s:8:\"response\";a:2:{s:12:\"twentyeleven\";a:3:{s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:47:\"http://wordpress.org/extend/themes/twentyeleven\";s:7:\"package\";s:64:\"http://wordpress.org/extend/themes/download/twentyeleven.1.3.zip\";}s:9:\"twentyten\";a:3:{s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:44:\"http://wordpress.org/extend/themes/twentyten\";s:7:\"package\";s:61:\"http://wordpress.org/extend/themes/download/twentyten.1.3.zip\";}}}'),(25,1,'blog_count','3'),(26,1,'user_count','2'),(27,1,'can_compress_scripts','1'),(28,1,'registrationnotification','yes'),(29,1,'menu_items','a:1:{s:7:\"plugins\";s:1:\"1\";}'),(30,1,'mu_media_buttons','a:1:{s:5:\"image\";s:1:\"1\";}'),(31,1,'welcome_user_email','Dear User,\r\n\r\nYour new account is set up.\r\n\r\nYou can log in with the following information:\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLOGINLINK\r\n\r\nThanks!\r\n\r\n--The Team @ SITE_NAME'),(34,1,'blog_count_ts','1301482799'),(36,1,'user_count_ts','1301472750'),(54,1,'_site_transient_timeout_browser_593a3e3d21a477af04e3df107141b3f9','1311506758'),(55,1,'_site_transient_browser_593a3e3d21a477af04e3df107141b3f9','a:9:{s:8:\"platform\";s:5:\"Linux\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"12.0.742.112\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"12\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}'),(56,1,'wpf_options','a:8:{s:11:\"wpf_wp_root\";s:36:\"/home/ludo/Desktop/dev/wp/wordpress/\";s:20:\"wpf_wp_logged_in_key\";s:64:\"GqmH/BQa?pd-@]s}z&Rp,]=sMTH?Mp2j>q>1fP+iT1Hq@Wi<S)0Fop#NOw)z~<HZ\";s:21:\"wpf_wp_logged_in_salt\";s:64:\"AQWUU[llB|v_G^.dR)Si6nCUcmUW>T^Y@]-#2fUP+f7sB,KQ`8y#3BC<0T+tLz$S\";s:26:\"wpf_support_category_order\";b:0;s:16:\"wpf_use_sendfile\";b:1;s:22:\"wpf_categories_as_sets\";b:1;s:18:\"wpf_global_favicon\";b:0;s:17:\"wpf_global_robots\";b:1;}'),(63,1,'_site_transient_timeout_browser_752461f27551e24868d80e41e6ec4e80','1314008678'),(64,1,'_site_transient_browser_752461f27551e24868d80e41e6ec4e80','a:9:{s:8:\"platform\";s:5:\"Linux\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"13.0.782.107\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"12\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}'),(66,1,'active_sitewide_plugins','a:2:{s:18:\"wp-unit/WPUnit.php\";i:1325171231;s:27:\"wp_frontman/wp_frontman.php\";i:1331735634;}'),(70,1,'_site_transient_timeout_wporg_theme_feature_list','1313595745'),(71,1,'_site_transient_wporg_theme_feature_list','a:0:{}'),(144,1,'initial_db_version','18226'),(146,1,'_site_transient_update_core','O:8:\"stdClass\":3:{s:7:\"updates\";a:0:{}s:15:\"version_checked\";s:5:\"3.3.1\";s:12:\"last_checked\";i:1332156068;}'),(173,1,'wp_frontman','a:20:{s:7:\"wp_root\";s:29:\"/var/virtual/wp/wordpress-mu/\";s:19:\"multisite_subdomain\";N;s:11:\"wp_auth_key\";s:64:\"Zj*jS 4&}i}xeXjfugcQ Q+`{sj-+}Qt<]jY ;izZmt|~4]EZ(ql;[gYsL!dE~=B\";s:12:\"wp_auth_salt\";s:64:\")Qb@Hqx-9j&:x7ZmOk}4@y41/Vrd|:}m1J<SSK9x| UB$uXI+EFsOIajm%`zKHt1\";s:13:\"wp_secret_key\";N;s:14:\"wp_secret_salt\";N;s:18:\"wp_secure_auth_key\";s:64:\"4IY6(.eBhW[-o}6,(e]y;8+h<o7|p~K0Bw7lG0*/9Ck{RZTa**dElOg+ylnEGf/I\";s:19:\"wp_secure_auth_salt\";s:64:\"#0UsetXPKrMeIy2NYJ]M9p itjn>P7)K,R<-4XAe=-Q?$zY-kZ,7+1SJ)LO64:tk\";s:16:\"wp_logged_in_key\";s:64:\"GqmH/BQa?pd-@]s}z&Rp,]=sMTH?Mp2j>q>1fP+iT1Hq@Wi<S)0Fop#NOw)z~<HZ\";s:17:\"wp_logged_in_salt\";s:64:\"AQWUU[llB|v_G^.dR)Si6nCUcmUW>T^Y@]-#2fUP+f7sB,KQ`8y#3BC<0T+tLz$S\";s:12:\"wp_nonce_key\";s:64:\"-Jwm-=+R}XA2F1gWS+/y2xVR2cCW(>n2.U}sKFR,3-d-Pe-v}0)ebMEbRa.T(q%P\";s:13:\"wp_nonce_salt\";s:64:\"M5`ju_DPV=Oy[vlg1?szPjH6tQ,ja/-upzZL]#~,r3VPU8>PK]J/b{b[ypm&r_@J\";s:18:\"builtin_post_types\";a:5:{s:4:\"post\";a:13:{s:8:\"_builtin\";b:1;s:15:\"capability_type\";s:4:\"post\";s:11:\"description\";s:0:\"\";s:19:\"exclude_from_search\";b:0;s:11:\"has_archive\";b:0;s:12:\"hierarchical\";b:0;s:5:\"label\";s:8:\"Articoli\";s:12:\"map_meta_cap\";b:1;s:4:\"name\";s:4:\"post\";s:6:\"public\";b:1;s:18:\"publicly_queryable\";b:1;s:7:\"rewrite\";b:0;s:10:\"taxonomies\";a:0:{}}s:4:\"page\";a:13:{s:8:\"_builtin\";b:1;s:15:\"capability_type\";s:4:\"page\";s:11:\"description\";s:0:\"\";s:19:\"exclude_from_search\";b:0;s:11:\"has_archive\";b:0;s:12:\"hierarchical\";b:1;s:5:\"label\";s:6:\"Pagine\";s:12:\"map_meta_cap\";b:1;s:4:\"name\";s:4:\"page\";s:6:\"public\";b:1;s:18:\"publicly_queryable\";b:0;s:7:\"rewrite\";b:0;s:10:\"taxonomies\";a:0:{}}s:10:\"attachment\";a:13:{s:8:\"_builtin\";b:1;s:15:\"capability_type\";s:4:\"post\";s:11:\"description\";s:0:\"\";s:19:\"exclude_from_search\";b:0;s:11:\"has_archive\";b:0;s:12:\"hierarchical\";b:0;s:5:\"label\";s:5:\"Media\";s:12:\"map_meta_cap\";b:1;s:4:\"name\";s:10:\"attachment\";s:6:\"public\";b:1;s:18:\"publicly_queryable\";b:1;s:7:\"rewrite\";b:0;s:10:\"taxonomies\";a:0:{}}s:8:\"revision\";a:13:{s:8:\"_builtin\";b:1;s:15:\"capability_type\";s:4:\"post\";s:11:\"description\";s:0:\"\";s:19:\"exclude_from_search\";b:1;s:11:\"has_archive\";b:0;s:12:\"hierarchical\";b:0;s:5:\"label\";s:9:\"Revisioni\";s:12:\"map_meta_cap\";b:1;s:4:\"name\";s:8:\"revision\";s:6:\"public\";b:0;s:18:\"publicly_queryable\";b:0;s:7:\"rewrite\";b:0;s:10:\"taxonomies\";a:0:{}}s:13:\"nav_menu_item\";a:13:{s:8:\"_builtin\";b:1;s:15:\"capability_type\";s:4:\"post\";s:11:\"description\";s:0:\"\";s:19:\"exclude_from_search\";b:1;s:11:\"has_archive\";b:0;s:12:\"hierarchical\";b:0;s:5:\"label\";s:32:\"Elementi del menu di navigazione\";s:12:\"map_meta_cap\";b:1;s:4:\"name\";s:13:\"nav_menu_item\";s:6:\"public\";b:0;s:18:\"publicly_queryable\";b:0;s:7:\"rewrite\";b:0;s:10:\"taxonomies\";a:0:{}}}s:18:\"builtin_taxonomies\";a:5:{s:8:\"category\";a:13:{s:8:\"_builtin\";b:1;s:12:\"hierarchical\";b:1;s:5:\"label\";s:9:\"Categorie\";s:4:\"name\";s:8:\"category\";s:11:\"object_type\";a:1:{i:0;s:4:\"post\";}s:6:\"public\";b:1;s:9:\"query_var\";s:13:\"category_name\";s:7:\"rewrite\";a:0:{}s:21:\"update_count_callback\";s:0:\"\";s:5:\"count\";b:0;s:12:\"rewrite_slug\";s:8:\"category\";s:18:\"rewrite_with_front\";b:1;s:20:\"rewrite_hierarchical\";b:1;}s:8:\"post_tag\";a:13:{s:8:\"_builtin\";b:1;s:12:\"hierarchical\";b:0;s:5:\"label\";s:3:\"Tag\";s:4:\"name\";s:8:\"post_tag\";s:11:\"object_type\";a:1:{i:0;s:4:\"post\";}s:6:\"public\";b:1;s:9:\"query_var\";s:3:\"tag\";s:7:\"rewrite\";a:0:{}s:21:\"update_count_callback\";s:0:\"\";s:5:\"count\";b:0;s:12:\"rewrite_slug\";s:3:\"tag\";s:18:\"rewrite_with_front\";b:1;s:20:\"rewrite_hierarchical\";b:0;}s:8:\"nav_menu\";a:10:{s:8:\"_builtin\";b:1;s:12:\"hierarchical\";b:0;s:5:\"label\";s:19:\"Menu di navigazione\";s:4:\"name\";s:8:\"nav_menu\";s:11:\"object_type\";a:1:{i:0;s:13:\"nav_menu_item\";}s:6:\"public\";b:0;s:9:\"query_var\";b:0;s:7:\"rewrite\";a:0:{}s:21:\"update_count_callback\";s:0:\"\";s:5:\"count\";b:0;}s:13:\"link_category\";a:10:{s:8:\"_builtin\";b:1;s:12:\"hierarchical\";b:0;s:5:\"label\";s:18:\"Categorie dei link\";s:4:\"name\";s:13:\"link_category\";s:11:\"object_type\";a:1:{i:0;s:4:\"link\";}s:6:\"public\";b:0;s:9:\"query_var\";b:0;s:7:\"rewrite\";a:0:{}s:21:\"update_count_callback\";s:0:\"\";s:5:\"count\";b:0;}s:11:\"post_format\";a:13:{s:8:\"_builtin\";b:1;s:12:\"hierarchical\";b:0;s:5:\"label\";s:7:\"Formato\";s:4:\"name\";s:11:\"post_format\";s:11:\"object_type\";a:1:{i:0;s:4:\"post\";}s:6:\"public\";b:1;s:9:\"query_var\";s:11:\"post_format\";s:7:\"rewrite\";a:0:{}s:21:\"update_count_callback\";s:0:\"\";s:5:\"count\";b:0;s:12:\"rewrite_slug\";s:4:\"type\";s:18:\"rewrite_with_front\";b:1;s:20:\"rewrite_hierarchical\";b:0;}}s:12:\"use_sendfile\";b:1;s:12:\"rewrite_vars\";a:14:{i:0;a:3:{i:0;s:6:\"%year%\";i:1;s:10:\"([0-9]{4})\";i:2;s:5:\"year=\";}i:1;a:3:{i:0;s:10:\"%monthnum%\";i:1;s:12:\"([0-9]{1,2})\";i:2;s:9:\"monthnum=\";}i:2;a:3:{i:0;s:5:\"%day%\";i:1;s:12:\"([0-9]{1,2})\";i:2;s:4:\"day=\";}i:3;a:3:{i:0;s:6:\"%hour%\";i:1;s:12:\"([0-9]{1,2})\";i:2;s:5:\"hour=\";}i:4;a:3:{i:0;s:8:\"%minute%\";i:1;s:12:\"([0-9]{1,2})\";i:2;s:7:\"minute=\";}i:5;a:3:{i:0;s:8:\"%second%\";i:1;s:12:\"([0-9]{1,2})\";i:2;s:7:\"second=\";}i:6;a:3:{i:0;s:10:\"%postname%\";i:1;s:7:\"([^/]+)\";i:2;s:5:\"name=\";}i:7;a:3:{i:0;s:9:\"%post_id%\";i:1;s:8:\"([0-9]+)\";i:2;s:2:\"p=\";}i:8;a:3:{i:0;s:8:\"%author%\";i:1;s:7:\"([^/]+)\";i:2;s:12:\"author_name=\";}i:9;a:3:{i:0;s:10:\"%pagename%\";i:1;s:8:\"([^/]+?)\";i:2;s:9:\"pagename=\";}i:10;a:3:{i:0;s:8:\"%search%\";i:1;s:4:\"(.+)\";i:2;s:2:\"s=\";}i:11;a:3:{i:0;s:10:\"%category%\";i:1;s:5:\"(.+?)\";i:2;s:14:\"category_name=\";}i:12;a:3:{i:0;s:10:\"%post_tag%\";i:1;s:7:\"([^/]+)\";i:2;s:4:\"tag=\";}i:13;a:3:{i:0;s:13:\"%post_format%\";i:1;s:7:\"([^/]+)\";i:2;s:12:\"post_format=\";}}s:13:\"rewrite_feeds\";a:5:{i:0;s:4:\"feed\";i:1;s:3:\"rdf\";i:2;s:3:\"rss\";i:3;s:4:\"rss2\";i:4;s:4:\"atom\";}s:11:\"_db_version\";i:2;s:7:\"_t_init\";i:1331737042;s:7:\"_t_save\";i:1331737042;}'),(176,1,'_site_transient_timeout_theme_roots','1332163268'),(177,1,'_site_transient_theme_roots','a:2:{s:12:\"twentyeleven\";s:7:\"/themes\";s:9:\"twentyten\";s:7:\"/themes\";}');
/*!40000 ALTER TABLE `wp_sitemeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_relationships`
--

LOCK TABLES `wp_term_relationships` WRITE;
/*!40000 ALTER TABLE `wp_term_relationships` DISABLE KEYS */;
INSERT INTO `wp_term_relationships` VALUES (1,2,0),(2,2,0),(2,6,0),(3,2,0),(4,2,0),(5,2,0),(5,6,0),(5,10,0),(5,11,0),(6,2,0),(7,2,0),(19,9,0),(19,16,0),(21,5,0),(23,5,0),(25,8,0),(28,1,0),(28,3,0),(28,10,0),(28,11,0),(28,12,0),(28,16,0),(40,1,0);
/*!40000 ALTER TABLE `wp_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_term_taxonomy`
--

DROP TABLE IF EXISTS `wp_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`),
  KEY `wp_term_taxonomy_ibfk2` (`parent`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_term_taxonomy`
--

LOCK TABLES `wp_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wp_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wp_term_taxonomy` VALUES (1,1,'category','',NULL,1),(2,2,'link_category','',NULL,7),(3,30,'category','',NULL,1),(4,4,'category','',NULL,0),(5,5,'category','',NULL,2),(6,6,'category','',30,1),(7,7,'category','',30,0),(8,8,'category','',4,1),(9,9,'category','',6,1),(10,10,'post_tag','',NULL,2),(11,11,'post_tag','',NULL,2),(12,12,'post_tag','',NULL,1),(13,4,'post_tag','',NULL,0),(14,31,'test','',0,0),(15,32,'test','',0,0),(16,33,'test','',31,2);
/*!40000 ALTER TABLE `wp_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_terms`
--

DROP TABLE IF EXISTS `wp_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_terms`
--

LOCK TABLES `wp_terms` WRITE;
/*!40000 ALTER TABLE `wp_terms` DISABLE KEYS */;
INSERT INTO `wp_terms` VALUES (1,'Uncategorized','uncategorized',0),(2,'Blogroll','blogroll',0),(4,'Second category','second-category',0),(5,'Third category','third-category',0),(6,'First category first child','first-category-first-child',0),(7,'First category second child','first-category-second-child',0),(8,'Second category first child','second-category-first-child',0),(9,'First category first subchild','first-category-first-subchild',0),(10,'tag1','tag1',0),(11,'tag2','tag2',0),(12,'tag3','tag3',0),(13,'Swindlerâ€™s List','swindler%e2%80%99s-list',0),(30,'First category','first-category',0),(31,'Test Taxonomy 1','test-taxonomy-1',0),(32,'Test Taxonomy 2','test-taxonomy-2',0),(33,'Test Taxonomy 1.1','test-taxonomy-1-1',0);
/*!40000 ALTER TABLE `wp_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'first_name',''),(2,1,'last_name',''),(3,1,'nickname','ludo'),(4,1,'description',''),(5,1,'rich_editing','true'),(6,1,'comment_shortcuts','false'),(7,1,'admin_color','fresh'),(8,1,'use_ssl','0'),(9,1,'show_admin_bar_front','true'),(11,1,'aim',''),(12,1,'yim',''),(13,1,'jabber',''),(14,1,'wp_capabilities','a:1:{s:13:\"administrator\";s:1:\"1\";}'),(15,1,'wp_user_level','10'),(16,1,'wp_user-settings','m9=o&m8=c&m1=c&m4=c&m3=c&m6=c&m5=c&editor=html&m7=c&m0=c&m2=c&align=left&urlbutton=none&imgsize=medium'),(17,1,'wp_user-settings-time','1325171226'),(18,1,'wp_dashboard_quick_press_last_post_id','42'),(19,1,'source_domain','localhost'),(20,1,'primary_blog','1'),(21,1,'wp_2_capabilities','a:1:{s:13:\"administrator\";s:1:\"1\";}'),(22,1,'wp_2_user_level','10'),(23,1,'wp_3_capabilities','a:1:{s:13:\"administrator\";s:1:\"1\";}'),(24,1,'wp_3_user_level','10'),(25,1,'closedpostboxes_dashboard','a:0:{}'),(26,1,'metaboxhidden_dashboard','a:3:{i:0;s:24:\"dashboard_incoming_links\";i:1;s:17:\"dashboard_primary\";i:2;s:19:\"dashboard_secondary\";}'),(27,1,'wp_2_user-settings','m9=o&m8=c&m1=c&m4=c&m3=c&m6=c&m5=c&editor=html&m7=c&m0=c&m2=c&align=left&urlbutton=none&imgsize=medium'),(28,1,'wp_2_user-settings-time','1326110443'),(29,1,'wp_2_dashboard_quick_press_last_post_id','3'),(30,1,'wp_3_user-settings','m9=o&m8=c&m1=c&m4=c&m3=c&m6=c&m5=c&editor=html&m7=c&m0=c&m2=c&align=left&urlbutton=none&imgsize=medium'),(31,1,'wp_3_user-settings-time','1331738421'),(32,1,'wp_3_dashboard_quick_press_last_post_id','7'),(33,1,'dismissed_wp_pointers','wp330_toolbar');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_users`
--

DROP TABLE IF EXISTS `wp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_users`
--

LOCK TABLES `wp_users` WRITE;
/*!40000 ALTER TABLE `wp_users` DISABLE KEYS */;
INSERT INTO `wp_users` VALUES (1,'ludo','$P$BtLQjU.je/Z1z/WbrPIluGUZ9foBqs0','ludo','ludo@qix.it','','2011-03-29 10:31:54','',0,'ludo',0,0),(2,'ludotest4','$P$Bf8eNGJk0.ESZeIiLU1rtujvxYHUs30','ludotest4','ludotest4@qix.it','','2011-04-19 14:43:10','ffcfb342c71725dd',0,'ludotest4',0,0);
/*!40000 ALTER TABLE `wp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wpf_job`
--

DROP TABLE IF EXISTS `wp_wpf_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wpf_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `process` varchar(48) NOT NULL,
  `tstamp` datetime NOT NULL,
  `error` tinyint(1) NOT NULL,
  `object_id` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_id` (`blog_id`,`process`),
  KEY `blog_id_process_timestamp` (`blog_id`,`process`,`tstamp`),
  KEY `wp_wpf_job_472bc96c` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpf_job`
--

LOCK TABLES `wp_wpf_job` WRITE;
/*!40000 ALTER TABLE `wp_wpf_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wpf_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wpf_redirects_redirect`
--

DROP TABLE IF EXISTS `wp_wpf_redirects_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wpf_redirects_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_id` int(11) NOT NULL,
  `old_path` varchar(255) NOT NULL,
  `new_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_id` (`blog_id`,`old_path`),
  KEY `wp_wpf_redirects_redirect_ae93dc10` (`old_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpf_redirects_redirect`
--

LOCK TABLES `wp_wpf_redirects_redirect` WRITE;
/*!40000 ALTER TABLE `wp_wpf_redirects_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wpf_redirects_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wp_wpf_sphinx`
--

DROP TABLE IF EXISTS `wp_wpf_sphinx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wp_wpf_sphinx` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `max_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `wp_wpf_sphinx_67f1b7ce` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_wpf_sphinx`
--

LOCK TABLES `wp_wpf_sphinx` WRITE;
/*!40000 ALTER TABLE `wp_wpf_sphinx` DISABLE KEYS */;
/*!40000 ALTER TABLE `wp_wpf_sphinx` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-03-19 12:23:00
